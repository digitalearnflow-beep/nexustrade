-- =====================================================
-- NEXUS TRADE — Supabase Tables Setup
-- Run this in Supabase → SQL Editor → New Query
-- =====================================================

-- 1. Leads table (email capture)
create table if not exists leads (
  id         bigserial primary key,
  email      text not null,
  source     text default 'website',
  created_at timestamptz default now()
);

-- Index for fast lookup by email
create index if not exists leads_email_idx on leads(email);
create index if not exists leads_created_idx on leads(created_at desc);

-- 2. Clicks table (affiliate tracking)
create table if not exists clicks (
  id         bigserial primary key,
  product    text not null,
  page       text default 'unknown',
  created_at timestamptz default now()
);

create index if not exists clicks_product_idx on clicks(product);
create index if not exists clicks_created_idx on clicks(created_at desc);

-- =====================================================
-- RLS (Row Level Security) — allow service role only
-- =====================================================
alter table leads  enable row level security;
alter table clicks enable row level security;

-- Service role bypasses RLS automatically.
-- Anon key policy: INSERT only (no SELECT — privacy)
create policy "anon_insert_leads"  on leads  for insert to anon with check (true);
create policy "anon_insert_clicks" on clicks for insert to anon with check (true);

-- =====================================================
-- Analytics views (optional — for admin dashboard)
-- =====================================================
create or replace view leads_by_day as
  select date_trunc('day', created_at) as day, count(*) as total
  from leads group by 1 order by 1 desc;

create or replace view clicks_by_product as
  select product, count(*) as total
  from clicks group by 1 order by 2 desc;

-- Done! Run and then deploy.
