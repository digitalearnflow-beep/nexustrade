// netlify/functions/capture-email.js
// Stores email leads in Supabase + forwards to Formspree

exports.handler = async (event) => {
  const h = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  }
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: h, body: '' }
  if (event.httpMethod !== 'POST')    return { statusCode: 405, headers: h, body: 'Method not allowed' }

  try {
    const { name, email, source } = JSON.parse(event.body || '{}')
    if (!email || !email.includes('@'))
      return { statusCode: 400, headers: h, body: JSON.stringify({ ok: false, error: 'Invalid email' }) }

    const supabaseUrl = process.env.SUPABASE_URL
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY

    // Store in Supabase
    if (supabaseUrl && supabaseKey) {
      await fetch(`${supabaseUrl}/rest/v1/leads`, {
        method: 'POST',
        headers: {
          'Content-Type':  'application/json',
          'apikey':         supabaseKey,
          'Authorization':  `Bearer ${supabaseKey}`,
          'Prefer':         'return=minimal',
        },
        body: JSON.stringify({ email, source: source || 'website', created_at: new Date().toISOString() }),
      })
    }

    // Also POST to Formspree
    await fetch('https://formspree.io/f/xpqklgdw', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ email, source: source || 'website', _subject: `New lead from NexusTrade: ${email}` }),
    }).catch(() => {})

    console.log(`[NexusTrade] Lead captured: ${email} from ${source}`)
    return { statusCode: 200, headers: h, body: JSON.stringify({ ok: true }) }
  } catch (e) {
    console.error('[NexusTrade] capture-email error:', e)
    return { statusCode: 500, headers: h, body: JSON.stringify({ ok: false, error: 'Server error' }) }
  }
}
