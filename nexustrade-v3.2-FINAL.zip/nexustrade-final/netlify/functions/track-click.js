// netlify/functions/track-click.js
// Tracks affiliate clicks in Supabase

exports.handler = async (event) => {
  const h = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  }
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: h, body: '' }

  try {
    const { affiliate, page } = JSON.parse(event.body || '{}')
    const supabaseUrl = process.env.SUPABASE_URL
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY

    if (supabaseUrl && supabaseKey && affiliate) {
      await fetch(`${supabaseUrl}/rest/v1/clicks`, {
        method: 'POST',
        headers: {
          'Content-Type':  'application/json',
          'apikey':         supabaseKey,
          'Authorization':  `Bearer ${supabaseKey}`,
          'Prefer':         'return=minimal',
        },
        body: JSON.stringify({ product: affiliate, page: page || 'unknown', created_at: new Date().toISOString() }),
      })
    }

    console.log(`[NexusTrade] Click tracked: ${affiliate} from ${page}`)
    return { statusCode: 200, headers: h, body: JSON.stringify({ ok: true }) }
  } catch (e) {
    console.error('[NexusTrade] track-click error:', e)
    return { statusCode: 500, headers: h, body: JSON.stringify({ ok: false }) }
  }
}
