// netlify/functions/signals.js
exports.handler = async (event) => {
  const h = { 'Access-Control-Allow-Origin':'*', 'Content-Type':'application/json' }
  if (event.httpMethod === 'OPTIONS') return { statusCode:204, headers:h, body:'' }
  // Production: connect Upstash Redis
  // const { Redis } = await import('@upstash/redis')
  // const redis = new Redis({ url: process.env.UPSTASH_REDIS_REST_URL, token: process.env.UPSTASH_REDIS_REST_TOKEN })
  // const signals = await redis.lrange('signals:latest', 0, 49)
  return { statusCode:200, headers:h, body: JSON.stringify({ ok:true, ts: new Date().toISOString() }) }
}
