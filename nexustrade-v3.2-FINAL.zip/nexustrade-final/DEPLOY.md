# NEXUS TRADE v3.2 FINAL — Deploy Guide

## ⚠️ SECURITY — Do First
Regenerate your Supabase keys (they were shared in chat):
1. Supabase → Settings → API → Regenerate anon key
2. Supabase → Settings → API → Regenerate service_role key
3. Copy the NEW keys into Netlify only (never in chat/code)

---

## Step 1: Supabase Tables (ONE TIME)
1. Supabase → SQL Editor → New Query
2. Paste entire `supabase-setup.sql` → Run
3. Tables created: `leads`, `clicks`

---

## Step 2: Netlify Environment Variables
Site Settings → Environment Variables → Add:

| Variable | Value |
|---|---|
| `SUPABASE_URL` | `https://zrvmcphungdenvznnous.supabase.co` |
| `SUPABASE_ANON_KEY` | (your NEW regenerated anon key) |
| `SUPABASE_SERVICE_ROLE_KEY` | (your NEW regenerated service role key) |

---

## Step 3: Build & Deploy
```bash
npm install
npm run build
# Drag dist/ to netlify.com/drop
```

---

## What's in v3.2 FINAL

### 💰 Pre-Sell Modal (NEW)
- Every affiliate click → 5s countdown modal with benefits
- Shows live signal context (symbol, direction, confidence)
- Progress bar + auto-redirect
- 350ms delay tracking before navigation
- GA event: `presell_cta_click`

### 📊 Sticky CTA Bar (UPGRADED)
- Shows LIVE signal name + confidence + rising trader count
- Added WhatsApp button alongside email CTA
- Dark pro design with gold border
- GA event: `sticky_cta_click`

### 🦸 Hero Section (UPGRADED)
- Benefits checklist (5 key points)
- WhatsApp CTA button in hero
- Social proof line: "12,847 traders active"
- GA events on all hero buttons

### ⭐ Testimonials (UPGRADED)
- 6 verified testimonials (was 3)
- Profit badges: "+4.2% in 6 hours"
- Trader roles and countries
- "As Featured In" trust strip

### 🎤 Voice Agent (FIXED)
- Removed auto-play (browser policy fix)
- 100% user-initiated only
- voiceschanged event listener
- Chrome long-utterance bug fixed

### 📈 Real Market Data
- BTC, ETH, SOL → CoinGecko (30s)
- EUR/USD, GBP/USD → Frankfurter (30s)
- XAU/USD → CoinGecko gold
- LIVE DATA badge in ticker

### 🗄️ Supabase Live
- Email leads stored instantly
- Affiliate clicks tracked per product
- Admin panel shows real data

### 📡 Affiliate System
- /go/crypto → Crypto Secrets
- /go/course → Trading Course
- /go/ebook  → eBook Bundle
- /go/marketing → Marketing Acc.
- /go/whatsapp → WhatsApp

---

## Testing Checklist

- [ ] Ticker shows ● LIVE DATA within 30s
- [ ] Click 🎤 → voice speaks
- [ ] Click any affiliate CTA → PreSell modal appears → auto-redirects
- [ ] Submit email → Supabase leads table updated
- [ ] Admin Panel → Emails tab → lead appears
- [ ] Admin Panel → Affiliates tab → click counted
- [ ] /go/crypto → redirects to affiliate
- [ ] GA Real-Time → see yourself active
- [ ] Mobile → sticky bar visible at bottom
- [ ] Exit mouse to top → exit popup fires
