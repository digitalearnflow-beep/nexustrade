# NexusTrade v3 — Complete Setup Guide

## 🚀 Deploy in 3 Minutes

### Step 1: Install & Build
```bash
npm install
npm run build
```

### Step 2: Deploy to Netlify
**Option A (easiest):** Drag the `dist/` folder to https://app.netlify.com/drop

**Option B (recommended):** Push to GitHub → connect repo in Netlify
- Build command:  `npm run build`
- Publish dir:    `dist`
- Functions dir:  `netlify/functions`

---

## 🔑 Environment Variables

In Netlify → Site Settings → Environment Variables, add:

| Variable | Where to get it | Required |
|----------|----------------|---------|
| `VITE_SUPABASE_URL` | supabase.com → Project Settings → API | For email capture |
| `VITE_SUPABASE_ANON_KEY` | supabase.com → Project Settings → API | For email capture |
| `UPSTASH_REDIS_REST_URL` | upstash.com → Redis → REST API | For signal caching |
| `UPSTASH_REDIS_REST_TOKEN` | upstash.com → Redis → REST API | For signal caching |
| `STRIPE_SECRET_KEY` | dashboard.stripe.com → API Keys | For payments |
| `VITE_STRIPE_PUBLIC_KEY` | dashboard.stripe.com → API Keys | For payments |
| `TELEGRAM_BOT_TOKEN` | @BotFather on Telegram | For alerts |

**All are optional for launch.** Site works fully without them (using simulated data).

---

## 🗄️ Supabase Setup (Free Tier — $0)

### 1. Create account at supabase.com

### 2. Create new project

### 3. Run this SQL in the SQL Editor:

```sql
-- Email leads table
create table email_leads (
  id uuid default gen_random_uuid() primary key,
  name text,
  email text not null unique,
  source text,
  created_at timestamptz default now()
);

-- Signals table
create table signals (
  id uuid default gen_random_uuid() primary key,
  symbol text not null,
  market text not null,
  direction text not null,
  price numeric not null,
  sl numeric,
  tp numeric,
  confidence int,
  rsi numeric,
  ema50 numeric,
  ema200 numeric,
  explanation text,
  status text default 'ACTIVE',
  created_at timestamptz default now()
);

-- Affiliate clicks table
create table affiliate_clicks (
  id uuid default gen_random_uuid() primary key,
  affiliate_name text,
  page text,
  created_at timestamptz default now()
);

-- Ad events table
create table ad_events (
  id uuid default gen_random_uuid() primary key,
  ad_type text,
  event text,
  page text,
  created_at timestamptz default now()
);

-- Row Level Security (important!)
alter table email_leads enable row level security;
alter table signals enable row level security;
alter table affiliate_clicks enable row level security;

-- Allow anon inserts for leads and clicks
create policy "Allow anon insert" on email_leads for insert with check (true);
create policy "Allow anon insert" on affiliate_clicks for insert with check (true);
create policy "Allow anon select signals" on signals for select using (true);
```

### 4. Copy your Project URL and Anon Key to Netlify env vars

---

## 💳 Stripe Payments Setup

### 1. Create account at stripe.com

### 2. Create products:
- **Pro Monthly** — $29/month (recurring)
- **Lifetime** — $197 (one-time payment)

### 3. Create Netlify function `stripe-checkout.js`:

```js
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY)

const PRICE_IDS = {
  pro:      'price_xxx',   // Replace with your Stripe price IDs
  lifetime: 'price_yyy',
}

exports.handler = async ({ body }) => {
  const { plan, email } = JSON.parse(body)
  const session = await stripe.checkout.sessions.create({
    mode:         plan === 'lifetime' ? 'payment' : 'subscription',
    customer_email: email,
    line_items:   [{ price: PRICE_IDS[plan], quantity: 1 }],
    success_url:  'https://nexustrade.ai/dashboard',
    cancel_url:   'https://nexustrade.ai/pricing',
  })
  return {
    statusCode: 200,
    headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
    body: JSON.stringify({ url: session.url })
  }
}
```

### 4. In PricingPage, replace `setUser()` with:
```js
const res = await fetch('/.netlify/functions/stripe-checkout', {
  method: 'POST',
  body: JSON.stringify({ plan: plan.name.toLowerCase(), email: 'user@example.com' })
})
const { url } = await res.json()
window.location.href = url
```

---

## 📡 Connect Real Market Data

Replace the simulated price tick in `useMarketData.js`:

### Binance (Crypto)
```js
const ws = new WebSocket('wss://stream.binance.com:9443/stream?streams=btcusdt@aggTrade/ethusdt@aggTrade/solusdt@aggTrade')
ws.onmessage = ({ data }) => {
  const { stream, data: d } = JSON.parse(data)
  // d.p = price, d.q = quantity
  // Update prices state
}
```

### Finnhub (Gold/Oil) — Free tier: 60 calls/min
```js
const ws = new WebSocket(`wss://ws.finnhub.io?token=${FINNHUB_KEY}`)
ws.onopen = () => {
  ws.send(JSON.stringify({ type:'subscribe', symbol:'OANDA:XAU_USD' }))
  ws.send(JSON.stringify({ type:'subscribe', symbol:'OANDA:WTICO_USD' }))
}
```

### OANDA (Forex)
```js
// Server-side Netlify function (streaming)
fetch(`https://stream-fxtrade.oanda.com/v3/accounts/${ACCOUNT}/pricing/stream?instruments=EUR_USD,GBP_USD`, {
  headers: { Authorization: `Bearer ${OANDA_TOKEN}` }
})
```

---

## 📲 Telegram Bot Setup

1. Message @BotFather on Telegram
2. Create new bot → get token
3. Create a channel, add bot as admin
4. Add `TELEGRAM_BOT_TOKEN` to Netlify env vars
5. Add this to your signal engine:

```js
await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    chat_id: '@YourChannelName',
    parse_mode: 'HTML',
    text: `🚨 <b>${sig.direction} ${sig.symbol}</b>
📊 Confidence: ${sig.confidence}%
💰 Entry: ${sig.price}
🛑 SL: ${sig.sl} | ✅ TP: ${sig.tp}
📈 Profit: +${sig.profitPct}%

${sig.explanation}

<a href="https://nexustrade.ai">View on NexusTrade →</a>`
  })
})
```

---

## 🎤 Upgrade Voice to ElevenLabs (Optional)

Replace Web Speech API in VoiceAgent component:

```js
const audio = await fetch('https://api.elevenlabs.io/v1/text-to-speech/VOICE_ID', {
  method: 'POST',
  headers: {
    'xi-api-key': process.env.ELEVENLABS_API_KEY,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    text: script,
    model_id: 'eleven_turbo_v2',
    voice_settings: { stability: 0.5, similarity_boost: 0.75 }
  })
})
const blob = await audio.blob()
new Audio(URL.createObjectURL(blob)).play()
```

---

## 📋 Feature Checklist

| Feature | Status |
|---------|--------|
| Premium White + Gold theme | ✅ |
| All Adsterra ad scripts (4 units) | ✅ |
| All 4 affiliate links + tracking | ✅ |
| Money Hook with countdown | ✅ |
| Email capture popup + form | ✅ |
| Sticky CTA bar | ✅ |
| 30 SEO blog articles | ✅ |
| WhatsApp viral share | ✅ |
| Exit intent popup | ✅ |
| PWA manifest | ✅ |
| SEO pages (BTC/Gold/Forex) | ✅ |
| Privacy Policy | ✅ |
| Terms & Conditions | ✅ |
| Trading Disclaimer | ✅ |
| Trust section + testimonials | ✅ |
| Win rate chart | ✅ |
| Admin panel | ✅ |
| Voice agent | ✅ |
| Footer with legal links | ✅ |
| Netlify functions (3) | ✅ |
| sitemap.xml + robots.txt | ✅ |

---

## 🔐 Admin Access

Login: `admin@nexustrade.ai` / `admin`

## 💡 Day 1 Revenue Checklist

1. ✅ Deploy site (free on Netlify)
2. ✅ Register Adsterra account → paste your codes (already integrated)
3. ✅ Register affiliate programs (heikoboos + digistore24 — all links live)
4. ✅ Submit to Google Search Console with sitemap.xml
5. ✅ Share 3 blog articles on Twitter/X with trading hashtags
6. ✅ Create 1 TikTok/Reel showing live signal from dashboard
