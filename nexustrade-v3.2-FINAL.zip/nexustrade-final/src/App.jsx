import { useState, useEffect, useRef, useCallback } from 'react'
import './styles/global.css'
import { useMarketData, ASSETS } from './hooks/useMarketData.js'
import { DesktopBannerAd, MobileStickyAd, NativeAd } from './components/AdComponents.jsx'
import { AFF, AFF_LIST, affForMarket, trackClick, AffLink } from './components/affiliates.js'
import BLOG_POSTS from './data/blogPosts.js'

/* ================================================================
   STYLE HELPERS
   ================================================================ */
const S = {
  btnGold: { background:'linear-gradient(135deg,#b8960c,#f0c040)', border:'none', color:'#fff', borderRadius:8, fontWeight:700, cursor:'pointer', fontFamily:"'Inter',sans-serif", transition:'transform .15s,box-shadow .15s' },
  btnOutline: { background:'transparent', border:'1.5px solid #b8960c', color:'#b8960c', borderRadius:8, fontWeight:700, cursor:'pointer', fontFamily:"'Inter',sans-serif", transition:'all .15s' },
  btnDark: { background:'#1a1a1a', border:'none', color:'#fff', borderRadius:8, fontWeight:700, cursor:'pointer', fontFamily:"'Inter',sans-serif", transition:'all .15s' },
  card: { background:'#fff', border:'1px solid rgba(0,0,0,.08)', borderRadius:10, boxShadow:'0 2px 16px rgba(0,0,0,.07)' },
  cardGold: { background:'#fff', border:'1px solid rgba(184,150,12,.18)', borderRadius:10, boxShadow:'0 2px 16px rgba(184,150,12,.08)' },
  grad: { background:'linear-gradient(135deg,#b8960c,#f0c040)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text' },
  mono: { fontFamily:"'JetBrains Mono',monospace" },
  serif: { fontFamily:"'Playfair Display',Georgia,serif" },
}
const hov = (el, on) => { el.style.transform = on ? 'translateY(-2px)' : ''; el.style.boxShadow = on ? '0 8px 24px rgba(184,150,12,.35)' : '' }

/* ================================================================
   COUNTDOWN RING
   ================================================================ */
function CountdownRing({ seconds = 60, size = 54 }) {
  const [left, setLeft] = useState(seconds)
  const r = 20; const circ = 2 * Math.PI * r
  useEffect(() => {
    setLeft(seconds)
    const t = setInterval(() => setLeft(p => p <= 1 ? seconds : p - 1), 1000)
    return () => clearInterval(t)
  }, [seconds])
  return (
    <div style={{ position:'relative', width:size, height:size, flexShrink:0 }}>
      <svg width={size} height={size} style={{ transform:'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(184,150,12,.15)" strokeWidth={3.5} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#b8960c" strokeWidth={3.5}
          strokeDasharray={circ} strokeDashoffset={circ * (1 - left / seconds)}
          strokeLinecap="round" style={{ transition:'stroke-dashoffset 1s linear' }} />
      </svg>
      <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center' }}>
        <span style={{ fontSize:12, fontWeight:800, ...S.mono, color:'#b8960c', lineHeight:1 }}>{left}</span>
        <span style={{ fontSize:7.5, color:'#9a9aaa', marginTop:1 }}>SEC</span>
      </div>
    </div>
  )
}

/* ================================================================
   CONFIDENCE BAR
   ================================================================ */
function ConfBar({ value, width = 70 }) {
  const col = value >= 85 ? '#1a7f4e' : value >= 72 ? '#b8960c' : '#1a6eb5'
  return (
    <div style={{ display:'flex', alignItems:'center', gap:7 }}>
      <div style={{ width, height:5, background:'#f0ede6', borderRadius:3, overflow:'hidden' }}>
        <div style={{ width:`${value}%`, height:'100%', background:`linear-gradient(90deg,${col},${col}99)`, borderRadius:3, transition:'width .6s ease' }} />
      </div>
      <span style={{ fontSize:12.5, fontWeight:800, color:col, ...S.mono }}>{value}%</span>
    </div>
  )
}

/* ================================================================
   SHARE BUTTONS
   ================================================================ */
function ShareBtns({ sig }) {
  const [copied, setCopied] = useState(false)
  const url  = typeof window !== 'undefined' ? window.location.origin : 'https://nexustrade.ai'
  const text = `🔥 Live ${sig.symbol} ${sig.direction} Signal — ${sig.confidence}% AI confidence!\nEntry: ${sig.price} | SL: ${sig.sl} | TP: ${sig.tp}\nFree signals: ${url}`
  return (
    <div style={{ display:'flex', gap:5, flexShrink:0 }}>
      <a href={`https://wa.me/?text=${encodeURIComponent(text)}`} target="_blank" rel="noopener noreferrer"
        style={{ background:'rgba(37,211,102,.1)', border:'1px solid rgba(37,211,102,.3)', color:'#25d366', borderRadius:6, padding:'4px 9px', fontSize:11.5, fontWeight:700, display:'flex', alignItems:'center', gap:3 }}>
        📲 <span className="hide-mob">Share</span>
      </a>
      <button onClick={async () => { try { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000) } catch {} }}
        style={{ background:copied?'rgba(26,127,78,.1)':'rgba(0,0,0,.04)', border:'1px solid rgba(0,0,0,.1)', color:copied?'#1a7f4e':'#5a5a6e', borderRadius:6, padding:'4px 9px', fontSize:11.5, fontWeight:700 }}>
        {copied ? '✓' : '🔗'}
      </button>
    </div>
  )
}


/* ================================================================
   PRE-SELL MODAL — Warms up visitor before affiliate redirect
   Shown for 3s then auto-redirects with tracking
   ================================================================ */
function PreSellModal({ aff, signal, onClose }) {
  const [countdown, setCountdown] = useState(5)
  const [redirecting, setRedirecting] = useState(false)
  const timerRef = useRef(null)

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setCountdown(p => {
        if (p <= 1) {
          clearInterval(timerRef.current)
          setRedirecting(true)
          setTimeout(() => { window.open(aff.url, '_blank'); onClose() }, 400)
          return 0
        }
        return p - 1
      })
    }, 1000)
    return () => clearInterval(timerRef.current)
  }, [aff.url, onClose])

  const goNow = () => {
    clearInterval(timerRef.current)
    // GA event
    try { if (typeof window.gtag === 'function') window.gtag('event','presell_cta_click',{ event_category:'affiliate', event_label:aff.label }) } catch {}
    // Track click (300ms delay so tracking fires before navigation)
    trackClick(aff.label, 'presell-modal')
    setTimeout(() => { window.open(aff.url, '_blank'); onClose() }, 350)
  }

  const benefits = {
    'Crypto Secrets Guide':    ['Exact entry/exit formulas used by 6-figure traders','Step-by-step crypto signal execution blueprint','Risk management system that protects capital'],
    'Trading Mastery Course':  ['4,200+ students earning from signals','Live trade setups with real market context','Trading psychology & discipline framework'],
    'Trading eBook Bundle':    ['3 complete eBooks — instant download','Advanced RSI, MACD & EMA strategy guides','Money management rules that eliminate big losses'],
    'Marketing Accelerator':   ['Build your own signal service in 30 days','Passive income from trading knowledge','Done-for-you templates & funnels'],
  }
  const bens = benefits[aff.label] || benefits['Crypto Secrets Guide']

  return (
    <div style={{ position:'fixed', inset:0, zIndex:9950, background:'rgba(0,0,0,.7)', display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
      onClick={onClose}>
      <div className="slide-up" style={{ ...S.cardGold, maxWidth:500, width:'100%', overflow:'hidden' }}
        onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div style={{ background:'linear-gradient(135deg,#b8960c,#d4af37)', padding:'16px 22px', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div>
            <div style={{ fontSize:10, color:'rgba(255,255,255,.8)', fontWeight:700, letterSpacing:.8, marginBottom:3 }}>YOU ARE BEING REDIRECTED TO</div>
            <div style={{ fontSize:16, fontWeight:800, color:'#fff' }}>{aff.label}</div>
          </div>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontSize:28, fontWeight:900, color:'#fff', ...S.mono, lineHeight:1 }}>{countdown}</div>
            <div style={{ fontSize:9, color:'rgba(255,255,255,.7)' }}>SEC</div>
          </div>
        </div>
        {/* Body */}
        <div style={{ padding:'22px 24px' }}>
          {signal && (
            <div style={{ background:'rgba(26,127,78,.06)', border:'1px solid rgba(26,127,78,.2)', borderRadius:8, padding:'10px 14px', marginBottom:18, display:'flex', alignItems:'center', gap:10 }}>
              <span style={{ fontSize:18 }}>📈</span>
              <div style={{ fontSize:12.5, color:'#1a1a1a', lineHeight:1.6 }}>
                <strong>{signal.symbol}</strong> {signal.direction} signal active —{' '}
                <strong style={{ color:'#1a7f4e' }}>{signal.confidence}% confidence</strong> · TP {signal.tp} · R:R 1:3
              </div>
            </div>
          )}
          <h3 style={{ fontSize:16, fontWeight:800, marginBottom:14, ...S.serif }}>What you're getting:</h3>
          <div style={{ display:'flex', flexDirection:'column', gap:9, marginBottom:22 }}>
            {bens.map((b, i) => (
              <div key={i} style={{ display:'flex', alignItems:'flex-start', gap:10, fontSize:13.5, color:'#1a1a1a', lineHeight:1.55 }}>
                <span style={{ color:'#1a7f4e', fontWeight:800, fontSize:15, flexShrink:0, marginTop:1 }}>✓</span>
                {b}
              </div>
            ))}
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:14 }}>
            <div style={{ flex:1, height:4, background:'#f0ede6', borderRadius:2, overflow:'hidden' }}>
              <div style={{ height:'100%', background:'linear-gradient(90deg,#b8960c,#f0c040)', borderRadius:2,
                width: redirecting ? '100%' : `${((5-countdown)/5)*100}%`, transition:'width 1s linear' }} />
            </div>
            <span style={{ fontSize:11, color:'#9a9aaa', flexShrink:0 }}>Redirecting…</span>
          </div>
          <button onClick={goNow} style={{ ...S.btnGold, width:'100%', padding:'13px', fontSize:14.5 }}
            onMouseOver={e => hov(e.currentTarget,true)} onMouseOut={e => hov(e.currentTarget,false)}>
            {redirecting ? '↗ Opening…' : `${aff.cta} (Skip Wait →)`}
          </button>
          <button onClick={onClose} style={{ background:'none', border:'none', color:'#9a9aaa', fontSize:12, cursor:'pointer', width:'100%', marginTop:10 }}>
            ← Stay on NexusTrade
          </button>
        </div>
        {/* Social proof footer */}
        <div style={{ borderTop:'1px solid rgba(184,150,12,.12)', padding:'10px 22px', background:'rgba(184,150,12,.03)', display:'flex', alignItems:'center', gap:8 }}>
          <span style={{ fontSize:13 }}>{'★'.repeat(5)}</span>
          <span style={{ fontSize:11.5, color:'#5a5a6e' }}>{aff.price} · Trusted by 12,000+ traders · Instant access</span>
        </div>
      </div>
    </div>
  )
}

/* ================================================================
   MONEY HOOK — Best Signal with countdown + urgency
   ================================================================ */
function MoneyHook({ sig, setView }) {
  const [traders] = useState(Math.floor(Math.random() * 8) + 4)
  if (!sig) return (
    <div style={{ ...S.cardGold, padding:'28px 24px', textAlign:'center' }}>
      <div className="spin" style={{ width:26, height:26, border:'2px solid #b8960c', borderTopColor:'transparent', borderRadius:'50%', margin:'0 auto 12px' }} />
      <p style={{ color:'#9a9aaa', fontSize:14 }}>Scanning 7 markets for best signal…</p>
    </div>
  )
  const isBuy = sig.direction === 'BUY'
  const dc    = isBuy ? '#1a7f4e' : '#c0392b'
  const aff   = affForMarket(sig.market)
  const profit = ((Math.abs(sig.tp - sig.price) / sig.price) * 100).toFixed(2)

  return (
    <div style={{ ...S.cardGold, overflow:'hidden' }} className="glow-gold">
      {/* Header */}
      <div style={{ background:'linear-gradient(90deg,#b8960c,#d4af37)', padding:'8px 20px', display:'flex', alignItems:'center', gap:10 }}>
        <span className="blink" style={{ width:7, height:7, borderRadius:'50%', background:'#fff', display:'inline-block' }} />
        <span style={{ fontSize:11, fontWeight:800, color:'#fff', letterSpacing:.6 }}>🔥 TODAY'S BEST SIGNAL — LIVE</span>
        <span style={{ marginLeft:'auto', fontSize:10, color:'rgba(255,255,255,.75)' }}>Updates every 60 seconds</span>
      </div>
      <div style={{ padding:'20px 22px', display:'flex', alignItems:'center', gap:18, flexWrap:'wrap' }}>
        <CountdownRing seconds={60} size={56} />
        <div style={{ flex:1, minWidth:200 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:6 }}>
            <span style={{ fontSize:22, fontWeight:800, ...S.serif }}>{sig.symbol}</span>
            <span style={{ background:isBuy?'rgba(26,127,78,.1)':'rgba(192,57,43,.1)', border:`1px solid ${dc}44`, color:dc, borderRadius:6, padding:'3px 11px', fontWeight:800, fontSize:12, ...S.mono }}>{sig.direction}</span>
            <span style={{ background:'rgba(184,150,12,.08)', border:'1px solid rgba(184,150,12,.25)', color:'#b8960c', borderRadius:4, padding:'2px 8px', fontSize:9.5, fontWeight:700 }}>{sig.market.toUpperCase()}</span>
          </div>
          <div style={{ ...S.mono, fontSize:11.5, color:'#5a5a6e', marginBottom:8 }}>
            Entry <strong style={{ color:'#1a1a1a' }}>{sig.price.toLocaleString()}</strong> · SL <strong>{sig.sl}</strong> · TP <strong style={{ color:'#1a7f4e' }}>{sig.tp}</strong>
          </div>
          <ConfBar value={sig.confidence} width={120} />
        </div>
        {/* Profit box */}
        <div style={{ textAlign:'center', background:'rgba(184,150,12,.06)', border:'1px solid rgba(184,150,12,.2)', borderRadius:10, padding:'14px 18px' }}>
          <div style={{ fontSize:10, color:'#9a9aaa', marginBottom:3 }}>PROFIT POTENTIAL</div>
          <div style={{ fontSize:26, fontWeight:800, color:'#b8960c', ...S.mono, lineHeight:1 }}>+{profit}%</div>
          <div style={{ fontSize:10, color:'#9a9aaa', marginTop:3 }}>R:R = {sig.rr}</div>
        </div>
        {/* CTA */}
        <div style={{ display:'flex', flexDirection:'column', gap:8, flexShrink:0 }}>
          <AffLink href={aff.url} name={aff.label} page="money-hook">
            <button style={{ ...S.btnGold, padding:'11px 20px', fontSize:13.5 }}
              onMouseOver={e => hov(e.currentTarget, true)} onMouseOut={e => hov(e.currentTarget, false)}>
              {aff.cta}
            </button>
          </AffLink>
          <button onClick={() => setView('dashboard')} style={{ ...S.btnOutline, padding:'8px 14px', fontSize:12 }}>
            See All Signals →
          </button>
        </div>
      </div>
      {/* Urgency */}
      <div className="urgent" style={{ padding:'7px 20px', borderTop:'1px solid rgba(192,57,43,.12)', display:'flex', alignItems:'center', gap:8 }}>
        <span style={{ fontSize:11, color:'#c0392b', fontWeight:700 }}>⚡ {traders} traders entered this signal in the last 2 minutes</span>
      </div>
    </div>
  )
}

/* ================================================================
   SIGNAL CARD
   ================================================================ */
function SignalCard({ sig, expanded, onToggle, blurred }) {
  const isBuy = sig.direction === 'BUY'
  const dc    = isBuy ? '#1a7f4e' : '#c0392b'
  const aff   = affForMarket(sig.market)
  return (
    <div style={{ ...S.card, border:`1px solid ${expanded ? dc + '44' : 'rgba(0,0,0,.08)'}`, overflow:'hidden', transition:'border-color .2s', position:'relative' }}>
      {blurred && (
        <div style={{ position:'absolute', inset:0, zIndex:10, backdropFilter:'blur(6px)', background:'rgba(250,250,250,.6)', display:'flex', alignItems:'center', justifyContent:'center', borderRadius:10 }}>
          <span style={{ color:'#b8960c', fontWeight:800, fontSize:13 }}>🔒 Upgrade to unlock</span>
        </div>
      )}
      <div onClick={onToggle} style={{ display:'flex', alignItems:'center', gap:10, padding:'13px 16px', cursor:'pointer', flexWrap:'wrap' }}>
        <div style={{ background:isBuy?'rgba(26,127,78,.08)':'rgba(192,57,43,.08)', border:`1px solid ${dc}33`, color:dc, borderRadius:6, padding:'4px 11px', fontWeight:800, fontSize:11.5, ...S.mono, minWidth:46, textAlign:'center' }}>{sig.direction}</div>
        <div style={{ flex:1, minWidth:90 }}>
          <div style={{ display:'flex', alignItems:'center', gap:7 }}>
            <span style={{ fontWeight:800, fontSize:14.5, ...S.serif }}>{sig.symbol}</span>
            <span style={{ background:'rgba(184,150,12,.07)', border:'1px solid rgba(184,150,12,.2)', color:'#b8960c', borderRadius:4, padding:'1px 6px', fontSize:9, fontWeight:700 }}>{sig.market.toUpperCase()}</span>
          </div>
          <div style={{ ...S.mono, fontSize:10.5, color:'#9a9aaa', marginTop:2 }}>
            Entry <strong style={{ color:'#1a1a1a' }}>{sig.price.toLocaleString()}</strong> · SL <strong>{sig.sl}</strong> · TP <strong style={{ color:dc }}>{sig.tp}</strong>
          </div>
        </div>
        <div style={{ textAlign:'right' }}>
          <ConfBar value={sig.confidence} />
          <div style={{ fontSize:10, color:'#9a9aaa', marginTop:3, ...S.mono }}>{sig.timestamp.toLocaleTimeString()}</div>
        </div>
        <ShareBtns sig={sig} />
        <AffLink href={aff.url} name={aff.label} page="signal-card">
          <button style={{ ...S.btnGold, padding:'7px 12px', fontSize:11.5, whiteSpace:'nowrap' }}
            onMouseOver={e => hov(e.currentTarget, true)} onMouseOut={e => hov(e.currentTarget, false)}>
            Trade Now ↗
          </button>
        </AffLink>
      </div>
      {expanded && (
        <div style={{ borderTop:'1px solid rgba(0,0,0,.06)', padding:'14px 16px', background:'#fafafa' }}>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(98px,1fr))', gap:9, marginBottom:12 }}>
            {[
              ['RSI 14', sig.rsi, sig.rsi < 30 ? '#1a7f4e' : sig.rsi > 70 ? '#c0392b' : '#b8960c'],
              ['ATR', sig.atr, '#1a6eb5'],
              ['EMA 50', sig.ema50, '#1a7f4e'],
              ['EMA 200', sig.ema200, '#9a9aaa'],
              ['Risk', sig.riskPct + '%', '#c0392b'],
              ['Target', sig.profitPct + '%', '#1a7f4e'],
              ['R:R', sig.rr, '#b8960c'],
              ['EMA Cross', sig.emaCross ? '✓ YES' : '✗ NO', sig.emaCross ? '#1a7f4e' : '#9a9aaa'],
            ].map(([label, val, col]) => (
              <div key={label} style={{ ...S.card, padding:'8px 11px' }}>
                <div style={{ fontSize:9, color:'#9a9aaa', marginBottom:3 }}>{label}</div>
                <div style={{ fontSize:13.5, fontWeight:700, color:col, ...S.mono }}>{val}</div>
              </div>
            ))}
          </div>
          <div style={{ background:'rgba(184,150,12,.04)', border:'1px solid rgba(184,150,12,.15)', borderRadius:8, padding:'11px 14px' }}>
            <div style={{ fontSize:9.5, color:'#b8960c', fontWeight:800, marginBottom:5 }}>AI ANALYSIS</div>
            <p style={{ fontSize:13, color:'#5a5a6e', lineHeight:1.78 }}>{sig.explanation}</p>
          </div>
        </div>
      )}
    </div>
  )
}

/* ================================================================
   EMAIL CAPTURE MODAL
   ================================================================ */
function EmailModal({ onClose, onSubmit, source }) {
  const [email,   setEmail]   = useState('')
  const [name,    setName]    = useState('')
  const [done,    setDone]    = useState(false)
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState('')
  const src = source || 'popup'

  const submit = async () => {
    setError('')
    if (!email.includes('@')) { setError('Please enter a valid email address.'); return }
    setLoading(true)
    try {
      await onSubmit(name, email, src)
      setDone(true)
      setTimeout(onClose, 2800)
    } catch {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ position:'fixed', inset:0, zIndex:9900, background:'rgba(0,0,0,.55)', display:'flex', alignItems:'center', justifyContent:'center', padding:20 }} onClick={onClose}>
      <div className="slide-up" style={{ ...S.cardGold, padding:'36px 32px', maxWidth:440, width:'100%', textAlign:'center' }} onClick={e => e.stopPropagation()}>
        {done ? (
          <>
            <div style={{ fontSize:48, marginBottom:12 }}>✅</div>
            <h2 style={{ fontSize:22, fontWeight:800, ...S.serif, marginBottom:8 }}>You're in!</h2>
            <p style={{ color:'#5a5a6e', fontSize:14, lineHeight:1.7 }}>Your first live signal is being prepared. Check your inbox — and WhatsApp us for instant alerts.</p>
            <a href="https://wa.me/923442441237" target="_blank" rel="noopener noreferrer"
              style={{ display:'inline-block', marginTop:18, ...S.btnGold, padding:'10px 22px', fontSize:13, borderRadius:8, textDecoration:'none' }}>
              📲 Get Instant Signals on WhatsApp
            </a>
          </>
        ) : (
          <>
            <div style={{ fontSize:40, marginBottom:12 }}>📊</div>
            <h2 style={{ fontSize:22, fontWeight:800, ...S.serif, marginBottom:8 }}>Get 7 Days Free Premium Signals</h2>
            <p style={{ color:'#5a5a6e', fontSize:14, marginBottom:24, lineHeight:1.65 }}>
              Live AI signals — BTC, Gold, Forex — delivered free for 7 days. No credit card required.
            </p>
            <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Your first name (optional)"
              style={{ width:'100%', padding:'10px 14px', fontSize:14, marginBottom:10, borderRadius:8, border:'1.5px solid rgba(0,0,0,.1)', boxSizing:'border-box' }} />
            <input type="email" value={email} onChange={e => { setEmail(e.target.value); setError('') }} placeholder="Your best email address"
              onKeyDown={e => e.key === 'Enter' && submit()}
              style={{ width:'100%', padding:'10px 14px', fontSize:14, marginBottom:error?8:16, borderRadius:8, border:`1.5px solid ${error?'#e74c3c':'rgba(0,0,0,.1)'}`, boxSizing:'border-box' }} />
            {error && <p style={{ color:'#e74c3c', fontSize:12, marginBottom:12, textAlign:'left' }}>⚠ {error}</p>}
            <button onClick={submit} disabled={loading}
              style={{ ...S.btnGold, width:'100%', padding:'13px', fontSize:15, opacity:loading?0.75:1 }}
              onMouseOver={e => !loading && hov(e.currentTarget, true)} onMouseOut={e => hov(e.currentTarget, false)}>
              {loading ? 'Sending…' : 'Send My Free Signals →'}
            </button>
            <p style={{ fontSize:11, color:'#9a9aaa', marginTop:12 }}>No spam. Unsubscribe anytime. 100% free.</p>
          </>
        )}
      </div>
    </div>
  )
}

/* ================================================================
   STICKY CTA BAR
   ================================================================ */
function StickyCTABar({ user, setView, setShowEmail, bestSignal }) {
  const [show,    setShow]    = useState(false)
  const [traders, setTraders] = useState(Math.floor(Math.random()*12)+6)
  useEffect(() => {
    const t = setTimeout(() => setShow(true), 5000)
    return () => clearTimeout(t)
  }, [])
  // Rotate trader count for urgency
  useEffect(() => {
    if (!show) return
    const i = setInterval(() => setTraders(p => p + Math.floor(Math.random()*3)), 18000)
    return () => clearInterval(i)
  }, [show])
  if (!show || user) return null
  const sig = bestSignal
  const urgencyText = sig
    ? `🚨 ${sig.symbol} ${sig.direction} — ${sig.confidence}% confidence · ${traders} traders just entered`
    : `🚨 Live signal active — ${traders} traders entering now`
  const handleCTAClick = () => {
    try { if (typeof window.gtag === 'function') window.gtag('event','sticky_cta_click',{ event_category:'conversion', event_label:'sticky-bar' }) } catch {}
    setShowEmail(true)
  }
  return (
    <div style={{
      position:'fixed', bottom:0, left:0, right:0, zIndex:8400,
      background:'linear-gradient(90deg,#1a1a1a 0%,#2a1f00 50%,#1a1a1a 100%)',
      padding:'9px 16px',
      display:'flex', alignItems:'center', justifyContent:'space-between', gap:10, flexWrap:'wrap',
      boxShadow:'0 -3px 24px rgba(0,0,0,.4)',
      borderTop:'2px solid #b8960c',
    }}>
      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
        <span className="blink" style={{ width:8, height:8, borderRadius:'50%', background:'#e74c3c', display:'inline-block', flexShrink:0 }} />
        <span style={{ color:'#fff', fontWeight:700, fontSize:13 }}>{urgencyText}</span>
      </div>
      <div style={{ display:'flex', gap:8, alignItems:'center' }}>
        <button onClick={handleCTAClick}
          style={{ background:'linear-gradient(135deg,#b8960c,#f0c040)', border:'none', color:'#fff', padding:'7px 18px', borderRadius:7, fontWeight:800, fontSize:13, cursor:'pointer', whiteSpace:'nowrap' }}>
          Get Free Signals →
        </button>
        <a href="https://wa.me/923442441237" target="_blank" rel="noopener noreferrer"
          style={{ background:'#25d366', border:'none', color:'#fff', padding:'7px 14px', borderRadius:7, fontWeight:800, fontSize:12, cursor:'pointer', textDecoration:'none', whiteSpace:'nowrap' }}>
          📲 WhatsApp
        </a>
        <button onClick={() => setShow(false)} style={{ background:'transparent', border:'none', color:'rgba(255,255,255,.5)', cursor:'pointer', fontSize:18, padding:'0 4px', lineHeight:1 }}>×</button>
      </div>
    </div>
  )
}

/* ================================================================
   TRUST SECTION
   ================================================================ */
function TrustSection({ setShowEmail }) {
  const reviews = [
    { name:'Ahmad K.',   country:'🇵🇰', role:'Crypto Trader',      text:'The BTC buy signal last week gave me 4.2% in 6 hours. Entry, SL, and TP were all perfectly calculated. Never seen accuracy like this.',    stars:5, profit:'+4.2%', time:'6 hours' },
    { name:'Maria S.',   country:'🇩🇪', role:'Forex Analyst',       text:'EUR/USD signals are spot on. I have been trading for 7 years and this is the most accurate signal tool I have ever used. R:R is always 1:3.', stars:5, profit:'+2.8%', time:'4 hours' },
    { name:'David O.',   country:'🇳🇬', role:'Full-time Trader',    text:'Started on the free plan and upgraded to Pro within 3 days. Gold signals alone paid for a full year's subscription within the first week.',    stars:5, profit:'+5.1%', time:'12 hours'},
    { name:'Tariq M.',   country:'🇸🇦', role:'Part-time Investor',  text:'I work a full-time job. NexusTrade signals let me trade profitably in just 15 minutes per day. The voice agent is a game-changer.',          stars:5, profit:'+3.7%', time:'8 hours' },
    { name:'Sophie L.',  country:'🇫🇷', role:'Technical Analyst',   text:'The AI explanation on each signal teaches me WHY the trade is valid — EMA cross, RSI, ATR levels. I am learning while earning.',              stars:5, profit:'+6.3%', time:'3 hours' },
    { name:'Raj P.',     country:'🇮🇳', role:'Crypto Enthusiast',   text:'SOL signal gave me 6% in under 3 hours. The confidence score and real-time entry price are what separates this from every other signal service.', stars:5, profit:'+6.0%', time:'3 hours' },
  ]
  return (
    <section style={{ padding:'64px 24px', maxWidth:1100, margin:'0 auto' }}>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))', gap:14, marginBottom:52 }}>
        {[['94.2%','Signal Accuracy','Last 90 days'],['12,847','Active Traders','Worldwide'],['$4.8M','Tracked Profit','Community'],['83%','Win Rate (30d)','Verified live']].map(([v, l, s]) => (
          <div key={l} style={{ ...S.cardGold, padding:'22px 18px', textAlign:'center' }}>
            <div style={{ fontSize:28, fontWeight:800, color:'#b8960c', ...S.mono }}>{v}</div>
            <div style={{ fontSize:13, fontWeight:700, marginTop:4, ...S.serif }}>{l}</div>
            <div style={{ fontSize:11, color:'#9a9aaa', marginTop:3 }}>{s}</div>
          </div>
        ))}
      </div>
      {/* Win rate chart */}
      <div style={{ ...S.card, padding:24, marginBottom:40 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:18, flexWrap:'wrap', gap:10 }}>
          <h3 style={{ fontSize:16, fontWeight:700, ...S.serif }}>Signal Performance <span style={{ fontSize:11, color:'#9a9aaa', fontFamily:'Inter,sans-serif', fontWeight:400 }}>— last 30 signals</span></h3>
          <div style={{ display:'flex', gap:14 }}>
            {[['Win','#1a7f4e'],['Loss','#c0392b'],['Pending','#9a9aaa']].map(([l, c]) => (
              <div key={l} style={{ display:'flex', alignItems:'center', gap:5, fontSize:11, color:c }}>
                <div style={{ width:8, height:8, borderRadius:'50%', background:c }} />{l}
              </div>
            ))}
          </div>
        </div>
        <div style={{ display:'flex', gap:3, alignItems:'flex-end', height:56 }}>
          {Array.from({ length:30 }, (_, i) => {
            const t = i < 25 ? 'win' : i < 28 ? 'loss' : 'pending'
            const h = 20 + Math.floor(Math.random() * 36)
            const c = t === 'win' ? '#1a7f4e' : t === 'loss' ? '#c0392b' : '#d4af37'
            return <div key={i} style={{ flex:1, height:`${h}px`, background:c, borderRadius:'2px 2px 0 0', opacity:.75 }} />
          })}
        </div>
        <div style={{ display:'flex', justifyContent:'space-between', marginTop:8 }}>
          <span style={{ fontSize:11, color:'#9a9aaa' }}>30 days ago</span>
          <span style={{ fontSize:12, fontWeight:700, color:'#1a7f4e' }}>83% Win Rate This Month</span>
          <span style={{ fontSize:11, color:'#9a9aaa' }}>Today</span>
        </div>
      </div>
      {/* Testimonials */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:16, marginBottom:36 }}>
        {reviews.map(r => (
          <div key={r.name} style={{ ...S.cardGold, padding:'20px 22px', display:'flex', flexDirection:'column' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10 }}>
              <div style={{ color:'#f0c040', fontSize:14 }}>{'★'.repeat(r.stars)}</div>
              <div style={{ background:'rgba(26,127,78,.08)', border:'1px solid rgba(26,127,78,.2)', color:'#1a7f4e', padding:'2px 9px', borderRadius:20, fontSize:11, fontWeight:700 }}>
                {r.profit} in {r.time}
              </div>
            </div>
            <p style={{ fontSize:13, color:'#5a5a6e', lineHeight:1.74, marginBottom:16, flex:1 }}>"{r.text}"</p>
            <div style={{ display:'flex', alignItems:'center', gap:10, borderTop:'1px solid rgba(184,150,12,.1)', paddingTop:12 }}>
              <div style={{ width:36, height:36, borderRadius:'50%', background:'linear-gradient(135deg,#b8960c,#f0c040)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:15, fontWeight:800, color:'#fff', flexShrink:0 }}>{r.name[0]}</div>
              <div>
                <div style={{ fontSize:13, fontWeight:700 }}>{r.name} {r.country}</div>
                <div style={{ fontSize:10.5, color:'#9a9aaa' }}>{r.role} · Verified User</div>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Trust logos row */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:24, flexWrap:'wrap', marginBottom:28, padding:'20px', background:'rgba(255,255,255,.6)', borderRadius:12, border:'1px solid rgba(0,0,0,.06)' }}>
        <span style={{ fontSize:11, color:'#9a9aaa', fontWeight:700, letterSpacing:.5 }}>AS FEATURED IN</span>
        {['CoinDesk', 'TradingView', 'Investopedia', 'CryptoSlate', 'FXStreet'].map(n => (
          <span key={n} style={{ fontSize:13, fontWeight:800, color:'#c0bdb0', letterSpacing:'-.3px' }}>{n}</span>
        ))}
      </div>
      {/* Disclaimer */}
      <div style={{ background:'rgba(184,150,12,.04)', border:'1px solid rgba(184,150,12,.2)', borderRadius:8, padding:'12px 16px' }}>
        <p style={{ fontSize:11.5, color:'#9a9aaa', lineHeight:1.7 }}>
          <strong style={{ color:'#b8960c' }}>Risk Disclaimer:</strong> Trading financial instruments involves substantial risk. Past signal performance does not guarantee future results. NexusTrade signals are for informational purposes only and do not constitute financial advice. Only trade with capital you can afford to lose. Always consult a qualified financial advisor.
        </p>
      </div>
    </section>
  )
}

/* ================================================================
   NAVBAR
   ================================================================ */
function NavBar({ view, setView, user, setUser, setShowEmail }) {
  const links = [['Dashboard','dashboard'],['Signals','signals'],['Blog','blog'],['Pricing','pricing']]
  return (
    <nav style={{
      position:'fixed', top:0, left:0, right:0, zIndex:1200,
      background:'rgba(254,254,254,.97)', backdropFilter:'blur(16px)',
      borderBottom:'1px solid rgba(0,0,0,.07)',
      height:62, display:'flex', alignItems:'center', padding:'0 20px', gap:14,
      boxShadow:'0 1px 12px rgba(0,0,0,.06)',
    }}>
      <div onClick={() => setView('landing')} style={{ display:'flex', alignItems:'center', gap:10, cursor:'pointer', flexShrink:0 }}>
        <div style={{ width:34, height:34, borderRadius:8, background:'linear-gradient(135deg,#b8960c,#f0c040)', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:900, fontSize:14, color:'#fff' }}>NT</div>
        <span style={{ fontWeight:800, fontSize:16, letterSpacing:'-.4px', ...S.serif }}>
          Nexus<span style={{ color:'#b8960c' }}>Trade</span>
        </span>
      </div>
      <div style={{ display:'flex', gap:2, flex:1, justifyContent:'center' }} className="hide-mob">
        {links.map(([l, v]) => (
          <button key={v} onClick={() => setView(v)} style={{
            background: view === v ? 'rgba(184,150,12,.08)' : 'transparent',
            border: `1px solid ${view === v ? 'rgba(184,150,12,.3)' : 'transparent'}`,
            color: view === v ? '#b8960c' : '#5a5a6e',
            padding:'6px 14px', borderRadius:7, fontSize:13, fontWeight:600, transition:'all .18s',
          }}>{l}</button>
        ))}
        {[['BTC Signal','btc-signal'],['Gold','gold-signal'],['Forex','forex-signals']].map(([l, v]) => (
          <button key={v} onClick={() => setView(v)} style={{
            background: view === v ? 'rgba(184,150,12,.06)' : 'transparent',
            border: `1px solid ${view === v ? 'rgba(184,150,12,.2)' : 'transparent'}`,
            color: view === v ? '#b8960c' : '#9a9aaa',
            padding:'6px 12px', borderRadius:7, fontSize:12, fontWeight:500,
          }}>{l}</button>
        ))}
      </div>
      <div style={{ display:'flex', gap:8, alignItems:'center', flexShrink:0 }}>
        {user ? (
          <>
            <span style={{ background:'linear-gradient(90deg,#b8960c,#d4af37)', color:'#fff', borderRadius:20, padding:'3px 11px', fontSize:11, fontWeight:800 }}>{user.plan.toUpperCase()}</span>
            {user.plan === 'admin' && <button onClick={() => setView('admin')} style={{ ...S.btnDark, padding:'5px 12px', fontSize:12 }}>Admin</button>}
            <button onClick={() => setUser(null)} style={{ background:'transparent', border:'1px solid rgba(0,0,0,.1)', color:'#5a5a6e', padding:'5px 12px', borderRadius:6, fontSize:12 }}>Logout</button>
          </>
        ) : (
          <>
            <button onClick={() => setShowEmail(true)} style={{ background:'transparent', border:'1px solid rgba(184,150,12,.4)', color:'#b8960c', padding:'6px 14px', borderRadius:7, fontSize:13, fontWeight:700, cursor:'pointer' }}>
              Get Free Signals
            </button>
            <button onClick={() => setView('pricing')} style={{ ...S.btnGold, padding:'7px 16px', fontSize:13 }}
              onMouseOver={e => hov(e.currentTarget, true)} onMouseOut={e => hov(e.currentTarget, false)}>
              Get Pro →
            </button>
          </>
        )}
      </div>
    </nav>
  )
}

/* ================================================================
   TICKER BAR
   ================================================================ */
function TickerBar({ prices, dataLive }) {
  const items = Object.entries(prices)
  return (
    <div style={{ position:'fixed', top:62, left:0, right:0, zIndex:1100, background:'#1a1a1a', height:30, overflow:'hidden' }}>
      <div style={{ display:'flex', alignItems:'center', height:'100%', animation:'ticker-move 52s linear infinite', width:'max-content' }}>
        {[...items, ...items].map(([sym, d], i) => {
          const showPct = d.pct24 !== undefined && d.pct24 !== 0 ? d.pct24 : d.pct
          return (
            <div key={i} style={{ display:'flex', alignItems:'center', gap:8, padding:'0 18px', borderRight:'1px solid rgba(255,255,255,.08)', ...S.mono, fontSize:11, whiteSpace:'nowrap' }}>
              {d.live && <span style={{ width:5, height:5, borderRadius:'50%', background:'#2ecc71', display:'inline-block', flexShrink:0 }} />}
              <span style={{ color:'rgba(255,255,255,.5)' }}>{sym}</span>
              <span style={{ fontWeight:700, color:'#fff' }}>{d.price.toLocaleString(undefined, { minimumFractionDigits:2, maximumFractionDigits:5 })}</span>
              <span style={{ color:showPct >= 0 ? '#2ecc71' : '#e74c3c', fontSize:10 }}>{showPct >= 0 ? '▲' : '▼'} {Math.abs(showPct).toFixed(2)}%</span>
            </div>
          )
        })}
        <div style={{ display:'flex', alignItems:'center', gap:5, padding:'0 18px', borderRight:'1px solid rgba(255,255,255,.08)', whiteSpace:'nowrap' }}>
          {dataLive
            ? <span style={{ fontSize:9.5, color:'#2ecc71', fontWeight:800, letterSpacing:.5 }}>● LIVE DATA</span>
            : <span style={{ fontSize:9.5, color:'#f39c12', fontWeight:800, letterSpacing:.5 }}>◌ LOADING...</span>
          }
        </div>
      </div>
    </div>
  )
}

/* ================================================================
   LANDING PAGE
   ================================================================ */
function LandingPage({ setView, signals, bestSignal, prices, isPaid, setShowEmail, setPreSell }) {
  const [exitPopup, setExitPopup] = useState(false)
  const fired = useRef(false)
  useEffect(() => {
    const h = e => { if (e.clientY < 8 && !fired.current) { fired.current = true; setTimeout(() => setExitPopup(true), 200) } }
    document.addEventListener('mousemove', h)
    return () => document.removeEventListener('mousemove', h)
  }, [])

  return (
    <div style={{ paddingTop:92 }}>
      {/* HERO */}
      <section style={{ minHeight:'90vh', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'52px 24px 40px', position:'relative', overflow:'hidden', textAlign:'center', background:'linear-gradient(180deg,#fefefe 0%,#f8f5ec 100%)' }}>
        <div style={{ position:'absolute', inset:0, backgroundImage:'radial-gradient(circle at 20% 30%, rgba(184,150,12,.06) 0%, transparent 50%), radial-gradient(circle at 80% 70%, rgba(212,175,55,.05) 0%, transparent 50%)', pointerEvents:'none' }} />
        <div style={{ position:'relative', zIndex:1, maxWidth:880 }}>
          <div style={{ display:'inline-flex', alignItems:'center', gap:8, background:'rgba(184,150,12,.08)', border:'1px solid rgba(184,150,12,.25)', borderRadius:24, padding:'6px 16px', marginBottom:28, fontSize:11.5, color:'#b8960c', ...S.mono }}>
            <span className="blink" style={{ width:7, height:7, borderRadius:'50%', background:'#b8960c', display:'inline-block' }} />
            LIVE · AI Scanning 7 Markets · {signals.length} Signals Today
          </div>
          <h1 style={{ fontSize:'clamp(32px,6vw,76px)', fontWeight:800, lineHeight:1.06, letterSpacing:'-2px', marginBottom:22, ...S.serif }}>
            AI Trading Signals<br />
            <span style={S.grad}>That Never Sleep</span>
          </h1>
          <p style={{ fontSize:17, color:'#5a5a6e', maxWidth:560, margin:'0 auto 28px', lineHeight:1.78 }}>
            Real-time AI signals — Crypto, Forex &amp; Gold. EMA crossovers, RSI, ATR risk management. 94% accuracy. Free to start.
          </p>
          {/* Benefits checklist */}
          <div style={{ display:'inline-flex', flexDirection:'column', gap:8, marginBottom:32, textAlign:'left' }}>
            {[
              '✅ Live signals every 60 seconds — 7 markets',
              '✅ AI explanation on every trade — entry, SL, TP',
              '✅ Real-time prices from CoinGecko & Frankfurter',
              '✅ Voice agent reads signals aloud — hands-free',
              '✅ 100% free — no credit card required',
            ].map((b, i) => (
              <div key={i} style={{ fontSize:14.5, color:'#1a1a1a', fontWeight:500 }}>{b}</div>
            ))}
          </div>
          <div style={{ display:'flex', gap:12, justifyContent:'center', flexWrap:'wrap', marginBottom:16 }}>
            <button style={{ ...S.btnGold, padding:'15px 34px', fontSize:16 }}
              onClick={() => {
                try { if (typeof window.gtag==='function') window.gtag('event','hero_cta_click',{event_category:'conversion',event_label:'hero-free-signals'}) } catch {}
                setShowEmail(true)
              }}
              onMouseOver={e => hov(e.currentTarget, true)} onMouseOut={e => hov(e.currentTarget, false)}>
              Get Free Signals →
            </button>
            <a href="https://wa.me/923442441237" target="_blank" rel="noopener noreferrer"
              style={{ ...S.btnOutline, padding:'15px 28px', fontSize:15, display:'flex', alignItems:'center', gap:8, textDecoration:'none' }}
              onClick={() => { try { if (typeof window.gtag==='function') window.gtag('event','whatsapp_cta_click',{event_category:'conversion',event_label:'hero-whatsapp'}) } catch {} }}>
              📲 Premium Signals on WhatsApp
            </a>
          </div>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:16, marginBottom:36, flexWrap:'wrap' }}>
            <span style={{ fontSize:12, color:'#9a9aaa' }}>🔒 No credit card · Instant access · Unsubscribe anytime</span>
            <span style={{ fontSize:12, color:'#1a7f4e', fontWeight:700 }}>⚡ 12,847 traders active right now</span>
          </div>
          <div style={{ maxWidth:780, margin:'0 auto' }}>
            <MoneyHook sig={bestSignal} setView={setView} />
          </div>
        </div>
      </section>

      {/* Banner ad */}
      <div style={{ background:'#f8f7f4', borderTop:'1px solid rgba(0,0,0,.06)', padding:'8px 0' }}>
        <DesktopBannerAd isPaid={isPaid} />
      </div>

      {/* Stats */}
      <section style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:1, background:'rgba(0,0,0,.06)' }}>
        {[['12,847','Active Traders'],['94.2%','Signal Accuracy'],['$4.8M','Tracked Profit'],['< 1ms','Latency']].map(([v, l]) => (
          <div key={l} style={{ background:'#fff', padding:'24px 18px', textAlign:'center' }}>
            <div style={{ fontSize:26, fontWeight:800, color:'#b8960c', ...S.mono }}>{v}</div>
            <div style={{ fontSize:12, color:'#9a9aaa', marginTop:4 }}>{l}</div>
          </div>
        ))}
      </section>

      {/* Features */}
      <section style={{ padding:'64px 24px', maxWidth:1100, margin:'0 auto' }}>
        <h2 style={{ textAlign:'center', fontSize:32, fontWeight:800, marginBottom:10, letterSpacing:'-1px', ...S.serif }}>
          Everything to <span style={S.grad}>Trade Smarter</span>
        </h2>
        <p style={{ textAlign:'center', color:'#9a9aaa', marginBottom:44, fontSize:15 }}>Professional tools. Zero learning curve.</p>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(285px,1fr))', gap:18 }}>
          {[
            { i:'⚡', t:'Real-Time Signals', d:'Sub-second signal generation from live Binance, OANDA & Finnhub WebSocket feeds. Multi-indicator AI validation before every alert.', c:'#1a7f4e' },
            { i:'🔥', t:'Money Hook System', d:"Today's Best Signal with live countdown, profit potential, and confidence score. Creates urgency and drives immediate action.", c:'#b8960c' },
            { i:'📲', t:'WhatsApp Viral Share', d:'One-tap share any signal to WhatsApp groups. Each shared signal drives new organic traffic back to your platform.', c:'#25d366' },
            { i:'📧', t:'Email Lead Capture', d:'Free 7-day signals lead magnet captures emails automatically. Grows your list 24/7 without active effort.', c:'#1a6eb5' },
            { i:'🎯', t:'ATR Risk Management', d:'Automatic SL/TP using Average True Range. Every signal includes pre-calculated risk percentage and profit potential.', c:'#c0392b' },
            { i:'📊', t:'7 Markets Covered', d:'BTC, ETH, SOL, EUR/USD, GBP/USD, Gold, Crude Oil — all signals unified in one premium dashboard.', c:'#b8960c' },
          ].map(f => (
            <div key={f.t} style={{ ...S.card, padding:24, transition:'all .22s' }}
              onMouseOver={e => { e.currentTarget.style.borderColor = f.c + '44'; e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = `0 12px 32px rgba(0,0,0,.1)` }}
              onMouseOut={e => { e.currentTarget.style.borderColor = 'rgba(0,0,0,.08)'; e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = '0 2px 16px rgba(0,0,0,.07)' }}>
              <div style={{ fontSize:28, marginBottom:11 }}>{f.i}</div>
              <h3 style={{ fontSize:15.5, fontWeight:700, marginBottom:8, color:f.c, ...S.serif }}>{f.t}</h3>
              <p style={{ fontSize:13.5, color:'#5a5a6e', lineHeight:1.74 }}>{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Native ad */}
      <div style={{ maxWidth:900, margin:'0 auto', padding:'0 24px 32px' }}>
        <NativeAd isPaid={isPaid} />
      </div>

      {/* Affiliates */}
      <section style={{ background:'#f8f5ec', borderTop:'1px solid rgba(0,0,0,.06)', borderBottom:'1px solid rgba(0,0,0,.06)', padding:'64px 24px' }}>
        <div style={{ maxWidth:980, margin:'0 auto', textAlign:'center' }}>
          <h2 style={{ fontSize:30, fontWeight:800, marginBottom:10, letterSpacing:'-1px', ...S.serif }}>Supercharge Your <span style={S.grad}>Trading Edge</span></h2>
          <p style={{ color:'#9a9aaa', marginBottom:40, fontSize:15 }}>Exclusively vetted resources used by our highest-performing traders</p>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(210px,1fr))', gap:16 }}>
            {AFF_LIST.map(aff => (
              <AffLink key={aff.label} href={aff.url} name={aff.label} page="landing-affiliate"
                style={{ ...S.card, padding:'22px 18px', display:'block', transition:'all .22s', textAlign:'left' }}
                className="">
                <div style={{ display:'block' }}
                  onMouseOver={e => { e.currentTarget.parentElement.style.borderColor = 'rgba(184,150,12,.4)'; e.currentTarget.parentElement.style.transform = 'translateY(-4px)' }}
                  onMouseOut={e => { e.currentTarget.parentElement.style.borderColor = 'rgba(0,0,0,.08)'; e.currentTarget.parentElement.style.transform = '' }}>
                  <div style={{ fontSize:10.5, color:'#b8960c', fontWeight:800, marginBottom:6 }}>{aff.badge}</div>
                  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:8 }}>
                    <h3 style={{ color:'#1a1a1a', fontSize:14.5, fontWeight:700, ...S.serif }}>{aff.label}</h3>
                    <span style={{ fontSize:13.5, fontWeight:800, color:'#b8960c' }}>{aff.price}</span>
                  </div>
                  <p style={{ color:'#5a5a6e', fontSize:12.5, lineHeight:1.65, marginBottom:14 }}>{aff.desc}</p>
                  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                    <span style={{ color:'#b8960c', fontWeight:800, fontSize:12.5 }}>{aff.ctaShort} →</span>
                    <span style={{ color:'#b8960c', fontSize:13 }}>{'★'.repeat(aff.stars)}</span>
                  </div>
                </div>
              </AffLink>
            ))}
          </div>
        </div>
      </section>

      <TrustSection setShowEmail={setShowEmail} />

      {/* Exit popup */}
      {exitPopup && (
        <div style={{ position:'fixed', inset:0, zIndex:9999, background:'rgba(0,0,0,.6)', display:'flex', alignItems:'center', justifyContent:'center' }} onClick={() => setExitPopup(false)}>
          <div className="slide-up" style={{ ...S.cardGold, padding:'36px 32px', maxWidth:460, width:'92%', textAlign:'center' }} onClick={e => e.stopPropagation()}>
            <div style={{ fontSize:44, marginBottom:14 }}>⚠️</div>
            <h2 style={{ fontSize:22, fontWeight:800, marginBottom:10, color:'#c0392b', ...S.serif }}>Wait — You're Missing a High-Probability Trade</h2>
            {bestSignal && (
              <div style={{ background:'rgba(184,150,12,.06)', border:'1px solid rgba(184,150,12,.2)', borderRadius:8, padding:'12px 16px', margin:'14px 0' }}>
                <strong>{bestSignal.symbol}</strong> just triggered a{' '}
                <strong style={{ color:bestSignal.direction === 'BUY' ? '#1a7f4e' : '#c0392b' }}>{bestSignal.direction}</strong>{' '}
                with <strong style={{ color:'#b8960c' }}>{bestSignal.confidence}% confidence</strong>.
                Profit potential: <strong style={{ color:'#1a7f4e' }}>+{bestSignal.profitPct}%</strong>
              </div>
            )}
            <p style={{ color:'#5a5a6e', fontSize:13.5, marginBottom:22, lineHeight:1.65 }}>Get free access — no credit card required.</p>
            <button onClick={() => { setExitPopup(false); setShowEmail(true) }} style={{ ...S.btnGold, width:'100%', padding:'13px', fontSize:15, marginBottom:10 }}>
              Unlock Free Signals Now →
            </button>
            <AffLink href={AFF.CRYPTO.url} name={AFF.CRYPTO.label} page="exit-popup">
              <div style={{ color:'#1a6eb5', fontSize:13, marginBottom:12, cursor:'pointer' }}>{AFF.CRYPTO.cta}</div>
            </AffLink>
            <button onClick={() => setExitPopup(false)} style={{ background:'none', border:'none', color:'#9a9aaa', cursor:'pointer', fontSize:12 }}>No thanks, I'll miss the trades</button>
          </div>
        </div>
      )}
    </div>
  )
}

/* ================================================================
   DASHBOARD
   ================================================================ */
function Dashboard({ prices, signals, bestSignal, isPaid, setView, setPreSell }) {
  const [expanded, setExpanded] = useState(null)
  const [filter, setFilter]     = useState('ALL')
  const filtered = filter === 'ALL' ? signals : signals.filter(s => s.market.toUpperCase() === filter)
  const avgConf  = signals.length ? Math.round(signals.reduce((a, s) => a + s.confidence, 0) / signals.length) : 0

  return (
    <div style={{ paddingTop:92, padding:'92px 18px 80px', maxWidth:1240, margin:'0 auto' }}>
      <DesktopBannerAd isPaid={isPaid} />
      <div style={{ margin:'16px 0 22px' }}><MoneyHook sig={bestSignal} setView={setView} /></div>
      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(150px,1fr))', gap:12, marginBottom:22 }}>
        {[
          { l:'Total Signals', v:signals.length, i:'📡', c:'#1a6eb5' },
          { l:'BUY Signals', v:signals.filter(s => s.direction === 'BUY').length, i:'📈', c:'#1a7f4e' },
          { l:'SELL Signals', v:signals.filter(s => s.direction === 'SELL').length, i:'📉', c:'#c0392b' },
          { l:'Avg Confidence', v:`${avgConf}%`, i:'🎯', c:'#b8960c' },
        ].map(s => (
          <div key={s.l} style={{ ...S.card, padding:'16px 18px', display:'flex', alignItems:'center', gap:11 }}>
            <span style={{ fontSize:22 }}>{s.i}</span>
            <div>
              <div style={{ fontSize:20, fontWeight:800, color:s.c, ...S.mono }}>{s.v}</div>
              <div style={{ fontSize:11, color:'#9a9aaa' }}>{s.l}</div>
            </div>
          </div>
        ))}
      </div>
      {/* Price grid */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(126px,1fr))', gap:9, marginBottom:22 }}>
        {Object.entries(prices).map(([sym, d]) => (
          <div key={sym} style={{ ...S.card, padding:'11px 13px' }}>
            <div style={{ fontSize:9.5, color:'#9a9aaa', ...S.mono, marginBottom:4 }}>{sym}</div>
            <div style={{ fontSize:13, fontWeight:700, ...S.mono }}>{d.price.toLocaleString(undefined, { minimumFractionDigits:2, maximumFractionDigits:5 })}</div>
            <div style={{ fontSize:10.5, ...S.mono, marginTop:2, color:d.pct >= 0 ? '#1a7f4e' : '#c0392b' }}>{d.pct >= 0 ? '▲' : '▼'} {Math.abs(d.pct).toFixed(3)}%</div>
            <div style={{ fontSize:9, color:'#c0bdb0', marginTop:2, ...S.mono }}>{d.bid} / {d.ask}</div>
          </div>
        ))}
      </div>
      {/* Signals + Sidebar */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 272px', gap:20 }}>
        <div>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12, flexWrap:'wrap', gap:8 }}>
            <h2 style={{ fontSize:17, fontWeight:800, ...S.serif, display:'flex', alignItems:'center', gap:8 }}>
              Live Signal Feed
              <span className="blink" style={{ width:8, height:8, borderRadius:'50%', background:'#1a7f4e', display:'inline-block' }} />
            </h2>
            <div style={{ display:'flex', gap:5 }}>
              {['ALL','CRYPTO','FOREX','COMMODITY'].map(m => (
                <button key={m} onClick={() => setFilter(m)} style={{
                  background: filter === m ? 'rgba(184,150,12,.08)' : 'transparent',
                  border: `1px solid ${filter === m ? 'rgba(184,150,12,.3)' : 'rgba(0,0,0,.1)'}`,
                  color: filter === m ? '#b8960c' : '#9a9aaa',
                  padding:'5px 10px', borderRadius:5, fontSize:11, fontWeight:600,
                }}>{m}</button>
              ))}
            </div>
          </div>
          {!isPaid && (
            <div style={{ background:'rgba(184,150,12,.04)', border:'1px solid rgba(184,150,12,.2)', borderRadius:9, padding:'10px 14px', marginBottom:12, display:'flex', alignItems:'center', justifyContent:'space-between', gap:10 }}>
              <span style={{ fontSize:12.5, color:'#5a5a6e' }}>🔒 Free: 5 signals. Upgrade for unlimited + AI analysis.</span>
              <button onClick={() => setView('pricing')} style={{ ...S.btnGold, padding:'6px 14px', fontSize:12, flexShrink:0 }}>Upgrade →</button>
            </div>
          )}
          <div style={{ display:'flex', flexDirection:'column', gap:9 }}>
            {filtered.length === 0 ? (
              <div style={{ textAlign:'center', padding:'44px 20px', border:'1px dashed rgba(0,0,0,.1)', borderRadius:11, color:'#9a9aaa' }}>
                <div className="spin" style={{ width:24, height:24, border:'2px solid #b8960c', borderTopColor:'transparent', borderRadius:'50%', margin:'0 auto 14px' }} />
                Analysing market data — signals appear in real time...
              </div>
            ) : filtered.map((sig, i) => (
              <div key={sig.id}>
                <SignalCard sig={sig} expanded={expanded === sig.id} onToggle={() => setExpanded(expanded === sig.id ? null : sig.id)} blurred={!isPaid && i >= 5} />
                {!isPaid && (i + 1) % 3 === 0 && i < filtered.length - 1 && (
                  <div style={{ margin:'6px 0' }}><NativeAd isPaid={isPaid} /></div>
                )}
              </div>
            ))}
          </div>
        </div>
        {/* Sidebar */}
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <div style={{ ...S.card, padding:18 }}>
            <div style={{ fontSize:10, color:'#9a9aaa', fontWeight:700, marginBottom:14, letterSpacing:.6 }}>MARKET SENTIMENT</div>
            {['BTC/USDT','ETH/USDT','EUR/USD','XAU/USD','GBP/USD'].map(sym => {
              const s = signals.find(x => x.symbol === sym)
              return (
                <div key={sym} style={{ marginBottom:12 }}>
                  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                    <span style={{ fontSize:11.5, ...S.mono, color:'#5a5a6e' }}>{sym}</span>
                    {s ? <span style={{ fontSize:11, fontWeight:800, color:s.direction === 'BUY' ? '#1a7f4e' : '#c0392b' }}>{s.direction}</span> : <span style={{ fontSize:10, color:'#c0bdb0' }}>–</span>}
                  </div>
                  {s ? <ConfBar value={s.confidence} width={140} /> : <div className="skeleton" style={{ height:5 }} />}
                </div>
              )
            })}
          </div>
          {/* Affiliate cards */}
          {[AFF.CRYPTO, AFF.BUSINESS].map((aff, i) => (
            <div key={aff.label} style={{ ...S.cardGold, padding:18 }}>
              <div style={{ fontSize:9.5, color:'#b8960c', fontWeight:800, marginBottom:6 }}>{aff.badge}</div>
              <h3 style={{ fontSize:14, fontWeight:700, marginBottom:7, ...S.serif }}>{aff.label}</h3>
              <p style={{ fontSize:12, color:'#5a5a6e', lineHeight:1.64, marginBottom:13 }}>{aff.desc}</p>
              <AffLink href={aff.url} name={aff.label} page="dashboard-sidebar">
                <button style={{ ...(i === 0 ? S.btnGold : S.btnOutline), width:'100%', padding:'9px', fontSize:12.5 }}
                  onMouseOver={e => hov(e.currentTarget, true)} onMouseOut={e => hov(e.currentTarget, false)}>
                  {aff.cta}
                </button>
              </AffLink>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ================================================================
   BLOG PAGE
   ================================================================ */
function BlogPage({ isPaid, setView }) {
  const [selectedPost, setSelectedPost] = useState(null)
  const [filter, setFilter] = useState('ALL')
  const tags = ['ALL', 'CRYPTO', 'GOLD', 'PASSIVE INCOME', 'COMMODITIES', 'EDUCATION', 'FOREX']
  const filtered = filter === 'ALL' ? BLOG_POSTS : BLOG_POSTS.filter(p => p.tag === filter)

  if (selectedPost) {
    const post = BLOG_POSTS.find(p => p.id === selectedPost)
    const aff  = AFF[post.affKey] || AFF.CRYPTO
    return (
      <div style={{ paddingTop:92, padding:'92px 22px 80px', maxWidth:780, margin:'0 auto' }}>
        <button onClick={() => setSelectedPost(null)} style={{ background:'transparent', border:'none', color:'#b8960c', fontSize:14, fontWeight:700, cursor:'pointer', marginBottom:20, display:'flex', alignItems:'center', gap:6 }}>← Back to Blog</button>
        <div style={{ ...S.cardGold, padding:'32px 36px' }}>
          <div style={{ display:'flex', gap:10, marginBottom:16 }}>
            <span style={{ background:'rgba(184,150,12,.1)', border:'1px solid rgba(184,150,12,.25)', color:'#b8960c', padding:'3px 10px', borderRadius:4, fontSize:10, fontWeight:700 }}>{post.tag}</span>
            <span style={{ color:'#9a9aaa', fontSize:12 }}>{post.readTime} read · {post.date}</span>
          </div>
          <h1 style={{ fontSize:'clamp(22px,4vw,32px)', fontWeight:800, marginBottom:16, letterSpacing:'-.5px', lineHeight:1.35, ...S.serif }}>{post.title}</h1>
          <div style={{ color:'#5a5a6e', fontSize:14, lineHeight:1.85, whiteSpace:'pre-wrap' }}>
            {post.body.split('\n\n').map((para, i) => (
              <p key={i} style={{ marginBottom:16 }} dangerouslySetInnerHTML={{
                __html: para
                  .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
                  .replace(/\[([^\]]+)\]\(([^)]+)\)/g, `<a href="$2" target="_blank" rel="noopener" style="color:#b8960c;font-weight:700">$1</a>`)
                  .replace(/^## (.+)/, '<h2 style="font-size:18px;font-weight:800;color:#1a1a1a;margin-bottom:8px;font-family:Playfair Display,Georgia,serif">$1</h2>')
                  .replace(/^# (.+)/, '<h1 style="font-size:22px;font-weight:800;color:#1a1a1a;font-family:Playfair Display,Georgia,serif">$1</h1>')
                  .replace(/^\*\*(\d+)\. (.+)\*\*/, '<h3 style="font-size:15px;font-weight:800;color:#1a1a1a;margin-bottom:4px">$1. $2</h3>')
              }} />
            ))}
          </div>
          {/* Affiliate CTA at end of article */}
          <div style={{ marginTop:32, ...S.cardGold, padding:'22px 24px', textAlign:'center' }}>
            <h3 style={{ fontSize:18, fontWeight:800, marginBottom:8, ...S.serif }}>{aff.label}</h3>
            <p style={{ color:'#5a5a6e', fontSize:13.5, marginBottom:16 }}>{aff.desc}</p>
            <AffLink href={aff.url} name={aff.label} page={`blog-article-${post.slug}`}>
              <button style={{ ...S.btnGold, padding:'11px 24px', fontSize:14 }}
                onMouseOver={e => hov(e.currentTarget, true)} onMouseOut={e => hov(e.currentTarget, false)}>
                {aff.cta}
              </button>
            </AffLink>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{ paddingTop:92, padding:'92px 22px 80px', maxWidth:1100, margin:'0 auto' }}>
      <div style={{ marginBottom:36 }}>
        <h1 style={{ fontSize:32, fontWeight:800, marginBottom:8, letterSpacing:'-1px', ...S.serif }}>Trading <span style={S.grad}>Intelligence</span> Blog</h1>

        <p style={{ color:'#9a9aaa', fontSize:15 }}>30 SEO-optimised articles — Crypto, Gold & Passive Income strategies</p>
      </div>
      {/* Tag filters */}
      <div style={{ display:'flex', gap:7, marginBottom:28, flexWrap:'wrap' }}>
        {tags.map(t => (
          <button key={t} onClick={() => setFilter(t)} style={{
            background: filter === t ? 'linear-gradient(135deg,#b8960c,#d4af37)' : '#fff',
            border: `1px solid ${filter === t ? 'transparent' : 'rgba(0,0,0,.1)'}`,
            color: filter === t ? '#fff' : '#5a5a6e',
            padding:'6px 14px', borderRadius:20, fontSize:12, fontWeight:600, cursor:'pointer',
          }}>{t}</button>
        ))}
      </div>
      <NativeAd isPaid={isPaid} style={{ marginBottom:28, borderRadius:10 }} />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))', gap:18 }}>
        {filtered.map((post, i) => {
          const aff = AFF[post.affKey] || AFF.CRYPTO
          return (
            <div key={post.id}>
              <div style={{ ...S.card, padding:'22px 24px', transition:'all .22s', cursor:'pointer' }}
                onMouseOver={e => { e.currentTarget.style.borderColor = 'rgba(184,150,12,.4)'; e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.boxShadow = '0 8px 28px rgba(0,0,0,.1)' }}
                onMouseOut={e => { e.currentTarget.style.borderColor = 'rgba(0,0,0,.08)'; e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = '0 2px 16px rgba(0,0,0,.07)' }}>
                <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:12 }}>
                  <span style={{ background:'rgba(184,150,12,.08)', border:'1px solid rgba(184,150,12,.2)', color:'#b8960c', padding:'2px 8px', borderRadius:4, fontSize:9.5, fontWeight:700 }}>{post.tag}</span>
                  <span style={{ color:'#9a9aaa', fontSize:11 }}>{post.readTime} read</span>
                </div>
                <h2 style={{ fontSize:16, fontWeight:700, marginBottom:9, letterSpacing:'-.2px', lineHeight:1.4, ...S.serif }}>{post.title}</h2>
                <p style={{ color:'#5a5a6e', fontSize:13, lineHeight:1.72, marginBottom:16 }}>{post.excerpt}</p>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                  <button onClick={() => setSelectedPost(post.id)} style={{ background:'transparent', border:'1px solid rgba(0,0,0,.1)', color:'#1a1a1a', padding:'7px 14px', borderRadius:6, cursor:'pointer', fontSize:12.5 }}>
                    Read Article →
                  </button>
                  <AffLink href={aff.url} name={aff.label} page={`blog-list-${post.slug}`}>
                    <span style={{ color:'#b8960c', fontSize:12.5, fontWeight:700 }}>{aff.ctaShort} →</span>
                  </AffLink>
                </div>
              </div>
              {!isPaid && i === 5 && <div style={{ marginTop:12 }}><NativeAd isPaid={isPaid} /></div>}
            </div>
          )
        })}
      </div>
    </div>
  )
}

/* ================================================================
   SEO PAGES
   ================================================================ */
function SeoPage({ title, symbol, market, description, signals, bestSignal, prices, isPaid, setView }) {
  const sigs = signals.filter(s => market === 'ALL' ? true : s.market === market).slice(0, 10)
  const price = prices[symbol]
  const aff   = affForMarket(market)
  const [expanded, setExpanded] = useState(null)

  return (
    <div style={{ paddingTop:92, padding:'92px 22px 80px', maxWidth:960, margin:'0 auto' }}>
      <div style={{ marginBottom:32 }}>
        <div style={{ display:'inline-flex', alignItems:'center', gap:7, background:'rgba(184,150,12,.07)', border:'1px solid rgba(184,150,12,.22)', borderRadius:20, padding:'5px 14px', marginBottom:16, fontSize:11, color:'#b8960c', ...S.mono }}>
          <span className="blink" style={{ width:7, height:7, borderRadius:'50%', background:'#b8960c', display:'inline-block' }} />
          LIVE · Updated Every 60 Seconds
        </div>
        <h1 style={{ fontSize:'clamp(22px,4vw,40px)', fontWeight:800, marginBottom:10, letterSpacing:'-1px', ...S.serif }}>{title}</h1>
        <p style={{ color:'#5a5a6e', fontSize:15, lineHeight:1.75, maxWidth:680 }}>{description}</p>
      </div>
      {price && (
        <div style={{ ...S.cardGold, padding:'18px 22px', marginBottom:22, display:'flex', alignItems:'center', gap:20, flexWrap:'wrap' }}>
          <div>
            <div style={{ fontSize:10, color:'#9a9aaa', marginBottom:4 }}>LIVE PRICE</div>
            <div style={{ fontSize:30, fontWeight:800, ...S.mono }}>{price.price.toLocaleString(undefined, { minimumFractionDigits:2, maximumFractionDigits:5 })}</div>
            <div style={{ fontSize:12, color:price.pct >= 0 ? '#1a7f4e' : '#c0392b', ...S.mono, marginTop:3 }}>{price.pct >= 0 ? '▲' : '▼'} {Math.abs(price.pct).toFixed(3)}% today</div>
          </div>
          <div style={{ marginLeft:'auto' }}>
            <AffLink href={aff.url} name={aff.label} page={`seo-${market}-top`}>
              <button style={{ ...S.btnGold, padding:'11px 22px', fontSize:14 }}
                onMouseOver={e => hov(e.currentTarget, true)} onMouseOut={e => hov(e.currentTarget, false)}>
                {aff.cta}
              </button>
            </AffLink>
          </div>
        </div>
      )}
      <div style={{ marginBottom:22 }}><MoneyHook sig={bestSignal || sigs[0]} setView={setView} /></div>
      <h2 style={{ fontSize:18, fontWeight:700, marginBottom:14, ...S.serif }}>Live {market.toUpperCase()} Signals</h2>
      <div style={{ display:'flex', flexDirection:'column', gap:9, marginBottom:28 }}>
        {sigs.length === 0 ? (
          <div style={{ ...S.card, padding:32, textAlign:'center', color:'#9a9aaa' }}>
            <div className="spin" style={{ width:22, height:22, border:'2px solid #b8960c', borderTopColor:'transparent', borderRadius:'50%', margin:'0 auto 12px' }} />
            Generating {market} signals…
          </div>
        ) : sigs.map((sig, i) => (
          <div key={sig.id}>
            <SignalCard sig={sig} expanded={expanded === sig.id} onToggle={() => setExpanded(expanded === sig.id ? null : sig.id)} blurred={!isPaid && i >= 3} />
            {!isPaid && i === 2 && <div style={{ margin:'6px 0' }}><NativeAd isPaid={isPaid} /></div>}
          </div>
        ))}
      </div>
      <div style={{ ...S.cardGold, padding:'28px 24px', textAlign:'center' }}>
        <h3 style={{ fontSize:20, fontWeight:800, marginBottom:10, ...S.serif }}>{aff.label}</h3>
        <p style={{ color:'#5a5a6e', fontSize:14, marginBottom:18, maxWidth:480, margin:'0 auto 18px' }}>{aff.desc}</p>
        <AffLink href={aff.url} name={aff.label} page={`seo-${market}-bottom`}>
          <button style={{ ...S.btnGold, padding:'12px 28px', fontSize:15 }}
            onMouseOver={e => hov(e.currentTarget, true)} onMouseOut={e => hov(e.currentTarget, false)}>
            {aff.cta}
          </button>
        </AffLink>
      </div>
    </div>
  )
}

/* ================================================================
   PRICING PAGE
   ================================================================ */
function PricingPage({ setUser, setView }) {
  const plans = [
    { name:'Free', price:'$0', period:'/month', popular:false,
      inc:['5 signals per day','BTC & ETH only','Basic indicators','Email alerts'],
      exc:['AI explanations','All 7 markets','Telegram bot','Ad-free dashboard'] },
    { name:'Pro', price:'$29', period:'/month', popular:true,
      inc:['Unlimited signals','All 7 markets','Full AI analysis','Telegram + email + push','Ad-free dashboard','All indicators','Signal history'],
      exc:[] },
    { name:'Lifetime', price:'$197', period:'once', popular:false,
      inc:['Everything in Pro','Lifetime access','API access','Signal webhooks','Priority support'],
      exc:[] },
  ]
  return (
    <div style={{ paddingTop:92, padding:'92px 24px 80px', maxWidth:1000, margin:'0 auto' }}>
      <div style={{ textAlign:'center', marginBottom:52 }}>
        <h1 style={{ fontSize:36, fontWeight:800, letterSpacing:'-1.5px', marginBottom:10, ...S.serif }}>
          Simple, <span style={S.grad}>Transparent</span> Pricing
        </h1>
        <p style={{ color:'#9a9aaa', fontSize:15 }}>Start free. Scale when you're profitable.</p>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))', gap:18 }}>
        {plans.map(plan => (
          <div key={plan.name} style={{ ...S.card, borderRadius:14, padding:30, position:'relative', border:plan.popular ? '2px solid #b8960c' : '1px solid rgba(0,0,0,.08)', transform:plan.popular ? 'scale(1.025)' : 'none', boxShadow:plan.popular ? '0 8px 40px rgba(184,150,12,.18)' : '0 2px 16px rgba(0,0,0,.07)' }}>
            {plan.popular && (
              <div style={{ position:'absolute', top:-13, left:'50%', transform:'translateX(-50%)', background:'linear-gradient(90deg,#b8960c,#d4af37)', color:'#fff', padding:'4px 16px', borderRadius:12, fontSize:11, fontWeight:800, whiteSpace:'nowrap' }}>MOST POPULAR</div>
            )}
            <div style={{ color:'#b8960c', fontSize:11, fontWeight:800, marginBottom:7 }}>{plan.name.toUpperCase()}</div>
            <div style={{ display:'flex', alignItems:'baseline', gap:3, marginBottom:24 }}>
              <span style={{ fontSize:40, fontWeight:800, ...S.mono }}>{plan.price}</span>
              <span style={{ color:'#9a9aaa', fontSize:13 }}>{plan.period}</span>
            </div>
            <div style={{ marginBottom:26 }}>
              {plan.inc.map(f => (
                <div key={f} style={{ display:'flex', gap:9, marginBottom:9, alignItems:'flex-start' }}>
                  <span style={{ color:'#1a7f4e', fontSize:13, flexShrink:0, marginTop:1 }}>✓</span>
                  <span style={{ fontSize:13.5 }}>{f}</span>
                </div>
              ))}
              {plan.exc.map(f => (
                <div key={f} style={{ display:'flex', gap:9, marginBottom:9, alignItems:'flex-start', opacity:.35 }}>
                  <span style={{ fontSize:13, flexShrink:0, marginTop:1 }}>✗</span>
                  <span style={{ fontSize:13.5, textDecoration:'line-through' }}>{f}</span>
                </div>
              ))}
            </div>
            <button onClick={() => { setUser({ plan:plan.name.toLowerCase(), email:'trader@nexustrade.ai' }); setView('dashboard') }}
              style={{ ...plan.popular ? S.btnGold : S.btnOutline, width:'100%', padding:'12px', fontSize:14 }}
              onMouseOver={e => plan.popular && hov(e.currentTarget, true)} onMouseOut={e => plan.popular && hov(e.currentTarget, false)}>
              {plan.name === 'Free' ? 'Start Free' : plan.name === 'Pro' ? 'Start Pro Trial' : 'Get Lifetime Access'}
            </button>
          </div>
        ))}
      </div>
      <div style={{ textAlign:'center', marginTop:36 }}>
        <p style={{ color:'#9a9aaa', fontSize:12.5 }}>Secure payments via Stripe · Cancel anytime · 30-day money-back guarantee</p>
        <div style={{ marginTop:16, display:'flex', justifyContent:'center', gap:22, flexWrap:'wrap' }}>
          {AFF_LIST.map(a => (
            <AffLink key={a.label} href={a.url} name={a.label} page="pricing-footer">
              <span style={{ color:'#1a6eb5', fontSize:12.5 }}>{a.label} →</span>
            </AffLink>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ================================================================
   LEGAL PAGES
   ================================================================ */
function LegalPage({ page }) {
  const content = {
    privacy: {
      title: 'Privacy Policy',
      updated: 'April 2025',
      body: [
        ['Information We Collect', 'We collect information you provide directly, including email addresses when you sign up for our free signal alerts. We also collect usage data through analytics to improve our service.'],
        ['How We Use Your Information', 'We use your email to send trading signals and promotional communications about our affiliate products. You can unsubscribe at any time. We do not sell your personal data to third parties.'],
        ['Cookies and Tracking', 'We use cookies to improve user experience and to serve relevant advertising through our ad partners (Adsterra). You may disable cookies in your browser settings.'],
        ['Third-Party Services', 'We use Adsterra for advertising, Supabase for database hosting, and Stripe for payment processing. Each has their own privacy policy.'],
        ['Affiliate Disclosure', 'This website contains affiliate links. When you click and purchase through these links, we may earn a commission at no additional cost to you.'],
        ['Data Retention', 'We retain your email address until you unsubscribe. Account data is retained for 2 years after last activity.'],
        ['Your Rights', 'You have the right to access, correct, or delete your personal data. Contact us at privacy@nexustrade.ai.'],
        ['Contact', 'For privacy inquiries: privacy@nexustrade.ai'],
      ]
    },
    terms: {
      title: 'Terms & Conditions',
      updated: 'April 2025',
      body: [
        ['Acceptance', 'By accessing NexusTrade, you agree to these terms. If you do not agree, please do not use our service.'],
        ['Service Description', 'NexusTrade provides AI-generated trading signal information for educational purposes only. We are not a regulated financial adviser, broker, or investment service.'],
        ['Not Financial Advice', 'All signals, analyses, and content on NexusTrade are for informational and educational purposes only. Nothing on this platform constitutes financial advice, investment advice, or a recommendation to buy or sell any financial instrument.'],
        ['User Responsibilities', 'You are solely responsible for your trading decisions. You acknowledge that trading involves substantial risk of loss and that past signal performance does not guarantee future results.'],
        ['Subscription Terms', 'Pro subscriptions are billed monthly. Lifetime subscriptions are one-time payments. You may cancel your subscription at any time. Refunds are available within 30 days of purchase.'],
        ['Intellectual Property', 'All content on NexusTrade including signal data, articles, and software is owned by NexusTrade and protected by copyright law.'],
        ['Limitation of Liability', 'NexusTrade shall not be liable for any losses resulting from use of our signals or service. Our maximum liability is limited to the subscription fees paid in the prior 3 months.'],
        ['Affiliate Links', 'This platform contains affiliate links. We may earn commissions when you click and purchase through these links.'],
        ['Modifications', 'We reserve the right to modify these terms at any time. Continued use of the service constitutes acceptance of modified terms.'],
      ]
    },
    disclaimer: {
      title: 'Trading Disclaimer',
      updated: 'April 2025',
      body: [
        ['High Risk Warning', 'Trading and investing in financial markets carries a high level of risk and may not be suitable for all investors. You may lose some or all of your invested capital. Do not trade with money you cannot afford to lose.'],
        ['No Financial Advice', 'The information provided on NexusTrade, including all trading signals, market analysis, blog articles, and AI commentary, is strictly for educational and informational purposes. It does not constitute financial advice, investment advice, trading advice, or any other form of advice.'],
        ['AI Signal Limitations', 'Our AI signals are generated by algorithms based on technical indicators. They are not infallible, and past accuracy rates do not guarantee future performance. Market conditions can change rapidly.'],
        ['Regulatory Notice', 'NexusTrade is not registered as a financial adviser, investment adviser, or broker-dealer with any regulatory authority. Users should consult a licensed financial professional before making investment decisions.'],
        ['Affiliate Relationships', 'NexusTrade has affiliate relationships with third-party product providers. We earn commissions when users purchase through our links. Our signal accuracy claims are independent of these affiliate relationships.'],
        ['Simulated Results', 'Any performance results shown on this platform may include simulated or hypothetical results. Simulated performance results have inherent limitations and may not reflect actual trading results.'],
        ['Jurisdiction', 'Trading certain financial instruments may not be legal in your jurisdiction. You are responsible for ensuring compliance with applicable local laws.'],
        ['Contact', 'For questions about this disclaimer: legal@nexustrade.ai'],
      ]
    }
  }
  const c = content[page]
  return (
    <div style={{ paddingTop:92, padding:'92px 24px 80px', maxWidth:780, margin:'0 auto' }}>
      <div style={{ ...S.card, padding:'36px 40px' }}>
        <h1 style={{ fontSize:30, fontWeight:800, marginBottom:6, ...S.serif }}>{c.title}</h1>
        <p style={{ color:'#9a9aaa', fontSize:13, marginBottom:32 }}>Last updated: {c.updated}</p>
        {c.body.map(([heading, text]) => (
          <div key={heading} style={{ marginBottom:24 }}>
            <h2 style={{ fontSize:16, fontWeight:700, marginBottom:8, color:'#b8960c', ...S.serif }}>{heading}</h2>
            <p style={{ fontSize:14, color:'#5a5a6e', lineHeight:1.8 }}>{text}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

/* ================================================================
   LOGIN PAGE
   ================================================================ */
function LoginPage({ setUser, setView }) {
  const [email, setEmail] = useState(''); const [pass, setPass] = useState('')
  const [err, setErr] = useState(''); const [loading, setLoading] = useState(false)
  const login = () => {
    if (!email.trim() || !pass.trim()) { setErr('Please enter email and password'); return }
    setLoading(true); setErr('')
    setTimeout(() => {
      setLoading(false)
      if (email === 'admin@nexustrade.ai' && pass === 'admin') { setUser({ plan:'admin', email }); setView('admin') }
      else { setUser({ plan:'pro', email }); setView('dashboard') }
    }, 900)
  }
  return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', padding:'90px 22px', background:'#f8f5ec' }}>
      <div style={{ ...S.cardGold, padding:'40px 36px', width:'100%', maxWidth:400 }}>
        <h1 style={{ fontSize:24, fontWeight:800, marginBottom:6, ...S.serif }}>Sign In</h1>
        <p style={{ color:'#9a9aaa', fontSize:13, marginBottom:26 }}>Access your trading dashboard</p>
        {err && <div style={{ background:'rgba(192,57,43,.08)', border:'1px solid rgba(192,57,43,.25)', borderRadius:7, padding:'9px 13px', marginBottom:14, fontSize:13, color:'#c0392b' }}>{err}</div>}
        {[['Email','email',email,setEmail],['Password','password',pass,setPass]].map(([l, t, v, s]) => (
          <div key={l} style={{ marginBottom:14 }}>
            <label style={{ fontSize:12, color:'#5a5a6e', display:'block', marginBottom:5, fontWeight:600 }}>{l}</label>
            <input type={t} value={v} onChange={e => s(e.target.value)} onKeyDown={e => e.key === 'Enter' && login()} style={{ width:'100%', padding:'10px 13px', fontSize:14 }} />
          </div>
        ))}
        <button onClick={login} disabled={loading} style={{ ...S.btnGold, width:'100%', padding:'12px', fontSize:14, marginTop:6, opacity:loading ? .7 : 1 }}
          onMouseOver={e => !loading && hov(e.currentTarget, true)} onMouseOut={e => hov(e.currentTarget, false)}>
          {loading ? 'Signing in…' : 'Sign In →'}
        </button>
        <p style={{ textAlign:'center', marginTop:16, fontSize:12.5, color:'#9a9aaa' }}>
          No account?{' '}
          <button onClick={() => setView('pricing')} style={{ background:'none', border:'none', color:'#b8960c', cursor:'pointer', fontSize:12.5, fontWeight:700 }}>Get started free →</button>
        </p>
        <p style={{ textAlign:'center', marginTop:8, fontSize:10.5, color:'#c0bdb0' }}>Demo: any email + password → Pro · admin@nexustrade.ai + admin → Admin</p>
      </div>
    </div>
  )
}

/* ================================================================
   ADMIN PANEL
   ================================================================ */
function AdminPanel({ signals }) {
  const [tab,     setTab]     = useState('overview')
  const [leads,   setLeads]   = useState([])
  const [clicks,  setClicks]  = useState([])
  const [loading, setLoading] = useState(true)
  const SUPA_URL = 'https://zrvmcphungdenvznnous.supabase.co'
  const SUPA_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inpydm1jcGh1bmdkZW52em5ub3VzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY2OTIyNTMsImV4cCI6MjA5MjI2ODI1M30.ql4ciH69j0krLxPZTAw9854a0wYmEriQ2a191RG6KkA'

  useEffect(() => {
    const headers = { apikey: SUPA_KEY, Authorization: `Bearer ${SUPA_KEY}` }
    Promise.all([
      fetch(`${SUPA_URL}/rest/v1/leads?select=*&order=created_at.desc&limit=50`, { headers }).then(r => r.ok ? r.json() : []).catch(() => []),
      fetch(`${SUPA_URL}/rest/v1/clicks?select=*&order=created_at.desc&limit=200`, { headers }).then(r => r.ok ? r.json() : []).catch(() => []),
    ]).then(([l, c]) => { setLeads(l || []); setClicks(c || []); setLoading(false) })
  }, [])

  // Aggregate click counts per product
  const clicksByProduct = clicks.reduce((acc, c) => { acc[c.product] = (acc[c.product]||0)+1; return acc }, {})
  const totalClicks = clicks.length
  const todayLeads  = leads.filter(l => new Date(l.created_at).toDateString() === new Date().toDateString()).length

  return (
    <div style={{ paddingTop:92, padding:'92px 22px 80px', maxWidth:1200, margin:'0 auto' }}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:22, flexWrap:'wrap', gap:10 }}>
        <h1 style={{ fontSize:25, fontWeight:800, ...S.serif }}>Admin Panel</h1>
        <div style={{ display:'flex', gap:10, alignItems:'center' }}>
          {loading && <span style={{ fontSize:12, color:'#9a9aaa' }}>Loading live data…</span>}
          <span style={{ background:'rgba(192,57,43,.08)', border:'1px solid rgba(192,57,43,.25)', color:'#c0392b', padding:'5px 12px', borderRadius:6, fontSize:11, fontWeight:700 }}>ADMIN ACCESS</span>
        </div>
      </div>
      <div style={{ display:'flex', gap:5, marginBottom:20, flexWrap:'wrap' }}>
        {['overview','signals','affiliates','ads','emails'].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ background:tab===t?'rgba(184,150,12,.08)':'transparent', border:`1px solid ${tab===t?'rgba(184,150,12,.3)':'rgba(0,0,0,.1)'}`, color:tab===t?'#b8960c':'#5a5a6e', padding:'7px 15px', borderRadius:6, fontSize:12, fontWeight:600, textTransform:'capitalize' }}>{t}</button>
        ))}
      </div>
      {tab === 'overview' && (
        <>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(148px,1fr))', gap:12, marginBottom:22 }}>
            {[['Email Leads',leads.length,'#b8960c'],['Today Leads',todayLeads,'#1a7f4e'],['Aff. Clicks',totalClicks,'#1a6eb5'],['Signals Today',signals.filter(s=>new Date(s.timestamp).toDateString()===new Date().toDateString()).length,'#b8960c'],['Active Signals',signals.filter(s=>s.status==='ACTIVE').length,'#1a7f4e'],['Markets Live',7,'#b8960c']].map(([l,v,c]) => (
              <div key={l} style={{ ...S.cardGold, padding:'18px 16px' }}>
                <div style={{ fontSize:9.5, color:'#9a9aaa', marginBottom:5 }}>{l}</div>
                <div style={{ fontSize:22, fontWeight:800, color:c, ...S.mono }}>{v}</div>
              </div>
            ))}
          </div>
          <div style={{ ...S.card, padding:22 }}>
            <h3 style={{ fontSize:15, fontWeight:700, marginBottom:16, ...S.serif }}>Recent Signals</h3>
            <table className="data-table">
              <thead><tr><th>Symbol</th><th>Direction</th><th>Confidence</th><th>Time</th><th>Status</th></tr></thead>
              <tbody>
                {signals.slice(0, 10).map(s => (
                  <tr key={s.id}>
                    <td style={{ fontWeight:700, ...S.mono }}>{s.symbol}</td>
                    <td style={{ color:s.direction==='BUY'?'#1a7f4e':'#c0392b', fontWeight:800, fontSize:12 }}>{s.direction}</td>
                    <td style={{ color:'#b8960c', fontWeight:700, ...S.mono }}>{s.confidence}%</td>
                    <td style={{ color:'#9a9aaa', ...S.mono, fontSize:11 }}>{s.timestamp.toLocaleTimeString()}</td>
                    <td><span style={{ background:'rgba(26,127,78,.08)', color:'#1a7f4e', padding:'2px 8px', borderRadius:4, fontSize:11 }}>ACTIVE</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
      {tab === 'affiliates' && (
        <div style={{ ...S.card, padding:26 }}>
          <h3 style={{ fontSize:15, fontWeight:700, marginBottom:18, ...S.serif }}>Affiliate Clicks (Live from Supabase)</h3>
          {loading ? <p style={{ color:'#9a9aaa', fontSize:13 }}>Loading…</p> : (
          <table className="data-table">
            <thead><tr><th>Product</th><th>Short Link</th><th>Clicks</th><th>Last Clicked</th></tr></thead>
            <tbody>
              {[
                [AFF.CRYPTO.label,   '/go/crypto'],
                [AFF.BUSINESS.label, '/go/course'],
                [AFF.EBOOK.label,    '/go/ebook'],
                [AFF.MARKETING.label,'/go/marketing'],
              ].map(([name, shortLink]) => {
                const cnt = clicksByProduct[name] || 0
                const last = clicks.find(c => c.product === name)
                return (
                  <tr key={name}>
                    <td style={{ fontWeight:700 }}>{name}</td>
                    <td style={{ ...S.mono, fontSize:11, color:'#1a6eb5' }}>{shortLink}</td>
                    <td style={{ color:'#1a6eb5', fontWeight:800, ...S.mono, fontSize:15 }}>{cnt}</td>
                    <td style={{ color:'#9a9aaa', fontSize:11, ...S.mono }}>{last ? new Date(last.created_at).toLocaleString() : '—'}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
          )}
          <div style={{ marginTop:18, padding:'12px 16px', background:'rgba(184,150,12,.04)', borderRadius:8, border:'1px solid rgba(184,150,12,.15)' }}>
            <p style={{ fontSize:12, color:'#5a5a6e' }}>
              Total tracked clicks: <strong style={{ color:'#b8960c' }}>{totalClicks}</strong> &nbsp;|&nbsp;
              Data updates on each page load. Click any affiliate link to test tracking.
            </p>
          </div>
        </div>
      )}
      {tab === 'ads' && (
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          {[['Social Bar (Global)','pl29145513.profitablecpmratenetwork.com','All pages — index.html head','✓ Active'],['Desktop Banner 728×90','highperformanceformat.com','Dashboard / between signals','✓ Active'],['Mobile Sticky 320×50','highperformanceformat.com','Mobile bottom sticky','✓ Active'],['Native Ads','pl29145521.profitablecpmratenetwork.com','Blog + signal feed every 3','✓ Active']].map(([n,d,p,st]) => (
            <div key={n} style={{ ...S.card, padding:'14px 20px', display:'grid', gridTemplateColumns:'200px 1fr 1fr 80px', gap:14, alignItems:'center' }}>
              <span style={{ fontWeight:700, fontSize:13 }}>{n}</span>
              <span style={{ ...S.mono, fontSize:10.5, color:'#9a9aaa' }}>{d}</span>
              <span style={{ fontSize:12, color:'#5a5a6e' }}>{p}</span>
              <span style={{ color:'#1a7f4e', fontWeight:700, fontSize:12 }}>{st}</span>
            </div>
          ))}
        </div>
      )}
      {tab === 'emails' && (
        <div style={{ ...S.card, padding:26 }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:18, flexWrap:'wrap', gap:10 }}>
            <h3 style={{ fontSize:15, fontWeight:700, ...S.serif }}>Email Leads — Live ({leads.length} total)</h3>
            <span style={{ fontSize:11, color:'#1a7f4e', fontWeight:700 }}>● Supabase Connected</span>
          </div>
          {loading ? <p style={{ color:'#9a9aaa', fontSize:13 }}>Loading leads…</p> : leads.length === 0 ? (
            <div style={{ textAlign:'center', padding:'32px 0', color:'#9a9aaa' }}>
              <div style={{ fontSize:32, marginBottom:10 }}>📭</div>
              <p style={{ fontSize:14 }}>No leads yet. Submit the email form to test.</p>
              <p style={{ fontSize:12, marginTop:8 }}>Check Supabase → Table Editor → leads if you expect data.</p>
            </div>
          ) : (
            <table className="data-table">
              <thead><tr><th>#</th><th>Email</th><th>Source</th><th>Date</th></tr></thead>
              <tbody>
                {leads.slice(0,30).map((l, i) => (
                  <tr key={l.id}>
                    <td style={{ color:'#9a9aaa', ...S.mono, fontSize:11 }}>{leads.length - i}</td>
                    <td style={{ fontWeight:600, ...S.mono, fontSize:12.5 }}>{l.email}</td>
                    <td><span style={{ background:'rgba(184,150,12,.08)', color:'#b8960c', padding:'2px 8px', borderRadius:4, fontSize:11 }}>{l.source||'website'}</span></td>
                    <td style={{ color:'#9a9aaa', fontSize:11, ...S.mono }}>{new Date(l.created_at).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  )
}

/* ================================================================
   VOICE AGENT
   ================================================================ */
function VoiceAgent({ signals, bestSignal, view, dataLive }) {
  const [active,   setActive]   = useState(false)
  const [speaking, setSpeaking] = useState(false)
  const [muted,    setMuted]    = useState(false)
  const [bubble,   setBubble]   = useState('')
  const [voices,   setVoices]   = useState([])
  const synthRef = useRef(null)

  // Load voices — must wait for voiceschanged event (Chrome async)
  useEffect(() => {
    if (!('speechSynthesis' in window)) return
    synthRef.current = window.speechSynthesis
    const loadVoices = () => setVoices(window.speechSynthesis.getVoices())
    loadVoices()
    window.speechSynthesis.addEventListener('voiceschanged', loadVoices)
    return () => window.speechSynthesis.removeEventListener('voiceschanged', loadVoices)
  }, [])

  const pickVoice = useCallback(() => {
    const all = voices.length ? voices : (window.speechSynthesis?.getVoices() || [])
    return all.find(v =>
      v.name.includes('Samantha') ||
      v.name.includes('Karen')    ||
      v.name.includes('Google UK English Female') ||
      v.name.includes('Microsoft Zira') ||
      (v.lang === 'en-US' && v.name.toLowerCase().includes('female')) ||
      v.lang === 'en-US' ||
      v.lang === 'en-GB'
    ) || all[0]
  }, [voices])

  const getScript = useCallback(() => {
    const priceStr = bestSignal ? `at ${bestSignal.price.toLocaleString()}` : ''
    const scripts = {
      landing:   `Welcome to NexusTrade! I'm your AI trading assistant. ${bestSignal ? `Right now, our top live signal is ${bestSignal.symbol} — a ${bestSignal.direction} ${priceStr}, with ${bestSignal.confidence} percent confidence and a profit target of ${bestSignal.profitPct} percent. ${dataLive ? 'These are real live prices.' : ''} Click to copy this trade on Binance.` : 'Live signals are loading across 7 markets right now.'}`,
      dashboard: bestSignal ? `${bestSignal.symbol} live ${bestSignal.direction} signal — ${bestSignal.confidence} percent AI confidence. Entry ${bestSignal.price}, stop loss ${bestSignal.sl}, take profit ${bestSignal.tp}. Risk reward one to three. ${dataLive ? 'Price is live from CoinGecko.' : ''} Click Trade Now to act on this signal.` : 'All 7 markets are being analysed with live prices. New signals appear every 60 seconds.',
      blog:      'Every article explains strategies our AI engine uses in real time. Check the RSI divergence article — those patterns have high historical accuracy.',
      pricing:   'Upgrade to Pro for unlimited signals across all 7 markets, full AI explanations, Telegram alerts, and an ad-free dashboard.',
    }
    return scripts[view] || scripts.landing
  }, [view, bestSignal, dataLive])

  const speak = useCallback((text) => {
    if (muted || !text) return
    const synth = synthRef.current || window.speechSynthesis
    if (!synth) return
    synth.cancel()
    // Short delay lets cancel() settle before speaking
    setTimeout(() => {
      const u = new SpeechSynthesisUtterance(text)
      u.rate   = 0.91
      u.pitch  = 1.05
      u.volume = 1.0
      const v  = pickVoice()
      if (v) u.voice = v
      u.onstart  = () => setSpeaking(true)
      u.onend    = () => setSpeaking(false)
      u.onerror  = (e) => { console.warn('TTS error', e.error); setSpeaking(false) }
      // Chrome bug: long utterances cut off — break into chunks
      if (text.length > 200) {
        const sentences = text.match(/[^.!?]+[.!?]+/g) || [text]
        sentences.forEach((s, i) => {
          const chunk = new SpeechSynthesisUtterance(s.trim())
          chunk.rate = 0.91; chunk.pitch = 1.05; chunk.volume = 1.0
          if (v) chunk.voice = v
          if (i === 0) chunk.onstart = () => setSpeaking(true)
          if (i === sentences.length - 1) {
            chunk.onend  = () => setSpeaking(false)
            chunk.onerror = () => setSpeaking(false)
          }
          synth.speak(chunk)
        })
      } else {
        synth.speak(u)
      }
    }, 80)
  }, [muted, pickVoice])

  const toggle = () => {
    const synth = synthRef.current || window.speechSynthesis
    if (active) {
      synth?.cancel()
      setSpeaking(false); setActive(false); setBubble('')
    } else {
      setActive(true)
      const msg = getScript()
      setBubble(msg)
      setTimeout(() => speak(msg), 350)
    }
  }
  // Only auto-update bubble text (no auto-speak — requires user click)
  useEffect(() => {
    if (active) {
      const msg = getScript()
      setBubble(msg)
      // Do NOT auto-speak — only speak on user-initiated toggle
    }
  }, [view, bestSignal])

  return (
    <div style={{ position:'fixed', bottom:64, right:18, zIndex:9100 }}>
      {active && bubble && (
        <div className="slide-up" style={{ position:'absolute', bottom:62, right:0, width:268, ...S.cardGold, padding:14, zIndex:9101 }}>
          <div style={{ fontSize:9.5, color:'#b8960c', fontWeight:800, marginBottom:5 }}>🤖 AI VOICE AGENT</div>
          <p style={{ fontSize:12.5, color:'#1a1a1a', lineHeight:1.66, marginBottom:10 }}>{bubble.slice(0, 160)}{bubble.length > 160 ? '…' : ''}</p>
          <AffLink href={AFF.BUSINESS.url} name={AFF.BUSINESS.label} page="voice-agent">
            <span style={{ color:'#b8960c', fontSize:11.5, fontWeight:800 }}>{AFF.BUSINESS.cta}</span>
          </AffLink>
        </div>
      )}
      {speaking && [0, 0.55].map(d => (
        <div key={d} style={{ position:'absolute', inset:-2, borderRadius:'50%', border:'2px solid #b8960c', opacity:.45, animation:`pulse-ring 1.6s ease-out infinite ${d}s`, pointerEvents:'none' }} />
      ))}
      <button onClick={toggle} style={{ width:50, height:50, borderRadius:'50%', background:active?'linear-gradient(135deg,#b8960c,#f0c040)':'#fff', border:'2px solid #b8960c', display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, boxShadow:active?'0 0 18px rgba(184,150,12,.4)':'0 2px 12px rgba(0,0,0,.1)', transition:'all .2s' }}>
        {speaking ? (
          <div style={{ display:'flex', gap:2, alignItems:'flex-end', height:18 }}>
            {[0, .12, .24, .36, .48].map((d, i) => (
              <div key={i} style={{ width:3, background:active?'#fff':'#b8960c', borderRadius:2, transformOrigin:'bottom', animation:`wave-bar .75s ease-in-out infinite`, animationDelay:`${d}s` }} />
            ))}
          </div>
        ) : active ? '🔊' : '🎤'}
      </button>
      {active && (
        <button onClick={() => { setMuted(!muted); window.speechSynthesis?.cancel(); setSpeaking(false) }}
          style={{ position:'absolute', top:-8, right:-8, width:20, height:20, borderRadius:'50%', background:'#fff', border:'1px solid rgba(0,0,0,.12)', cursor:'pointer', fontSize:10, display:'flex', alignItems:'center', justifyContent:'center', color:'#5a5a6e' }}>
          {muted ? '🔇' : '🔈'}
        </button>
      )}
    </div>
  )
}

/* ================================================================
   FOOTER
   ================================================================ */
function Footer({ setView }) {
  return (
    <footer style={{ background:'#1a1a1a', color:'rgba(255,255,255,.6)', padding:'40px 24px 20px', marginTop:0 }}>
      <div style={{ maxWidth:1100, margin:'0 auto' }}>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:32, marginBottom:32 }}>
          <div>
            <div style={{ display:'flex', alignItems:'center', gap:9, marginBottom:14 }}>
              <div style={{ width:30, height:30, borderRadius:7, background:'linear-gradient(135deg,#b8960c,#f0c040)', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:900, fontSize:13, color:'#fff' }}>NT</div>
              <span style={{ fontWeight:800, fontSize:15, color:'#fff', fontFamily:'Playfair Display,Georgia,serif' }}>NexusTrade</span>
            </div>
            <p style={{ fontSize:12.5, lineHeight:1.7, maxWidth:220 }}>AI-powered real-time trading signals for Crypto, Forex & Commodities. 94% accuracy.</p>
          </div>
          <div>
            <h4 style={{ color:'#fff', fontSize:13, fontWeight:700, marginBottom:14 }}>Platform</h4>
            {[['Dashboard','dashboard'],['Signals','signals'],['Blog','blog'],['Pricing','pricing']].map(([l, v]) => (
              <button key={v} onClick={() => setView(v)} style={{ display:'block', background:'none', border:'none', color:'rgba(255,255,255,.5)', fontSize:13, marginBottom:9, cursor:'pointer', padding:0, textAlign:'left' }}>{l}</button>
            ))}
          </div>
          <div>
            <h4 style={{ color:'#fff', fontSize:13, fontWeight:700, marginBottom:14 }}>Signals</h4>
            {[['BTC Signal Today','btc-signal'],['Forex Signals Live','forex-signals'],['Gold Signal','gold-signal']].map(([l, v]) => (
              <button key={v} onClick={() => setView(v)} style={{ display:'block', background:'none', border:'none', color:'rgba(255,255,255,.5)', fontSize:13, marginBottom:9, cursor:'pointer', padding:0, textAlign:'left' }}>{l}</button>
            ))}
          </div>
          <div>
            <h4 style={{ color:'#fff', fontSize:13, fontWeight:700, marginBottom:14 }}>Resources</h4>
            {[['Crypto Secrets',AFF.CRYPTO.url],['Trading Course',AFF.BUSINESS.url],['eBook Bundle',AFF.EBOOK.url],['Marketing Acc.',AFF.MARKETING.url]].map(([l, u]) => (
              <a key={l} href={u} target="_blank" rel="noopener noreferrer" style={{ display:'block', color:'rgba(255,255,255,.5)', fontSize:13, marginBottom:9 }}>{l} ↗</a>
            ))}
          </div>
          <div>
            <h4 style={{ color:'#fff', fontSize:13, fontWeight:700, marginBottom:14 }}>Legal</h4>
            {[['Privacy Policy','privacy'],['Terms & Conditions','terms'],['Trading Disclaimer','disclaimer']].map(([l, v]) => (
              <button key={v} onClick={() => setView(v)} style={{ display:'block', background:'none', border:'none', color:'rgba(255,255,255,.5)', fontSize:13, marginBottom:9, cursor:'pointer', padding:0, textAlign:'left' }}>{l}</button>
            ))}
          </div>
        </div>
        <div style={{ borderTop:'1px solid rgba(255,255,255,.08)', paddingTop:18, display:'flex', justifyContent:'space-between', flexWrap:'wrap', gap:12 }}>
          <p style={{ fontSize:12 }}>© 2025 NexusTrade. All rights reserved.</p>
          <p style={{ fontSize:11.5, maxWidth:500, color:'rgba(255,255,255,.35)' }}>
            Risk warning: Trading financial instruments involves substantial risk. Past performance is not indicative of future results. Not financial advice.
          </p>
        </div>
      </div>
    </footer>
  )
}

/* ================================================================
   MAIN APP
   ================================================================ */
export default function App() {
  const [view,      setView]      = useState('landing')
  const [user,      setUser]      = useState(null)
  const [showEmail, setShowEmail] = useState(false)
  const [preSell,   setPreSell]   = useState(null)   // { aff, signal } — pre-sell modal
  const { prices, signals, bestSignal, dataLive } = useMarketData()
  const isPaid = !!(user && ['pro','lifetime','admin'].includes(user.plan))

  // Email submit handler — stores to Supabase in production
  const handleEmailSubmit = async (name, email, source) => {
    const src = source || 'website-popup'
    try {
      const res = await fetch('/.netlify/functions/capture-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, source: src }),
      })
      if (typeof window.gtag === 'function')
        window.gtag('event', 'lead_captured', { event_category: 'email', event_label: src })
    } catch {
      fetch('https://formspree.io/f/xpqklgdw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ email, source: src }),
      }).catch(() => {})
    }
  }

  // Page titles + GA page view tracking
  useEffect(() => {
    const titles = { landing:'NexusTrade | AI Trading Signals — Crypto, Forex & Gold', dashboard:'Dashboard — NexusTrade', signals:'Live Signals — NexusTrade', blog:'Trading Intelligence Blog — NexusTrade', pricing:'Pricing — NexusTrade', 'btc-signal':'BTC Signal Today — Live Bitcoin AI Signal | NexusTrade', 'forex-signals':'Forex Signals Live — EUR/USD GBP/USD | NexusTrade', 'gold-signal':'Gold Trading Signal Today — XAU/USD | NexusTrade', privacy:'Privacy Policy — NexusTrade', terms:'Terms & Conditions — NexusTrade', disclaimer:'Trading Disclaimer — NexusTrade', admin:'Admin Panel — NexusTrade' }
    document.title = titles[view] || 'NexusTrade'
    // Track page view in GA
    try {
      if (typeof window.gtag === 'function') {
        window.gtag('event', 'page_view', {
          page_title:    document.title,
          page_location: window.location.href,
          page_path:     `/${view}`,
        })
      }
    } catch {}
  }, [view])

  // Show email popup for new visitors after 12s
  useEffect(() => { const t = setTimeout(() => { if (!user && !showEmail) setShowEmail(true) }, 12000); return () => clearTimeout(t) }, [user])

  return (
    <>
      <NavBar view={view} setView={setView} user={user} setUser={setUser} setShowEmail={setShowEmail} />
      <TickerBar prices={prices} dataLive={dataLive} />

      {showEmail && <EmailModal onClose={() => setShowEmail(false)} onSubmit={handleEmailSubmit} />}
      {preSell   && <PreSellModal aff={preSell.aff} signal={preSell.signal} onClose={() => setPreSell(null)} />}

      <main style={{ paddingBottom: isPaid ? 0 : 54, minHeight:'100vh' }}>
        {view === 'landing'       && <LandingPage setView={setView} signals={signals} bestSignal={bestSignal} prices={prices} isPaid={isPaid} setShowEmail={setShowEmail} setPreSell={setPreSell} />}
        {(view==='dashboard'||view==='signals') && <Dashboard prices={prices} signals={signals} bestSignal={bestSignal} isPaid={isPaid} setView={setView} setPreSell={setPreSell} />}
        {view === 'blog'          && <BlogPage isPaid={isPaid} setView={setView} />}
        {view === 'pricing'       && <PricingPage setUser={setUser} setView={setView} />}
        {view === 'login'         && <LoginPage setUser={setUser} setView={setView} />}
        {view === 'admin'         && <AdminPanel signals={signals} />}
        {view === 'privacy'       && <LegalPage page="privacy" />}
        {view === 'terms'         && <LegalPage page="terms" />}
        {view === 'disclaimer'    && <LegalPage page="disclaimer" />}
        {view === 'btc-signal'    && <SeoPage title="BTC Signal Today — Live Bitcoin AI Trading Signal" symbol="BTC/USDT" market="crypto" description="Our AI scans Bitcoin price action in real time using EMA crossovers, RSI 14, and ATR-based risk management. Updates every 60 seconds with the latest BTC buy or sell signal, entry price, stop loss and take profit." signals={signals} bestSignal={bestSignal} prices={prices} isPaid={isPaid} setView={setView} />}
        {view === 'forex-signals' && <SeoPage title="Forex Signals Live — EUR/USD & GBP/USD AI Signals" symbol="EUR/USD" market="forex" description="Real-time AI-generated forex signals for EUR/USD and GBP/USD. Updated every 60 seconds using EMA 50/200 crossovers, RSI divergence, and ATR stop loss calculations." signals={signals} bestSignal={bestSignal} prices={prices} isPaid={isPaid} setView={setView} />}
        {view === 'gold-signal'   && <SeoPage title="Gold Trading Signal Today — XAU/USD AI Signal Live" symbol="XAU/USD" market="commodity" description="Live AI trading signal for Gold (XAU/USD). Updated every 60 seconds. EMA crossovers, RSI and ATR used to generate high-accuracy buy and sell signals for gold traders." signals={signals} bestSignal={bestSignal} prices={prices} isPaid={isPaid} setView={setView} />}
      </main>

      <Footer setView={setView} />
      <VoiceAgent signals={signals} bestSignal={bestSignal} view={view} dataLive={dataLive} />
      <StickyCTABar user={user} setView={setView} setShowEmail={setShowEmail} bestSignal={bestSignal} />
      <MobileStickyAd isPaid={isPaid} />
    </>
  )
}
