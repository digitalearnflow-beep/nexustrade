import { useState, useEffect, useRef, useCallback } from 'react'

/* ================================================================
   ASSET REGISTRY
   Real data:
     Crypto:  CoinGecko public API (free, no key)
     Forex:   Frankfurter API (free, no key)
   ================================================================ */
export const ASSETS = {
  'BTC/USDT': { coinId:'bitcoin',  vol:800,   market:'crypto',    icon:'₿',  dp:2, fallback:67420 },
  'ETH/USDT': { coinId:'ethereum', vol:35,    market:'crypto',    icon:'Ξ',  dp:2, fallback:3280  },
  'SOL/USDT': { coinId:'solana',   vol:2.4,   market:'crypto',    icon:'◎',  dp:2, fallback:182   },
  'EUR/USD':  { forex:'EUR',       vol:.0004, market:'forex',     icon:'€',  dp:5, fallback:1.0872},
  'GBP/USD':  { forex:'GBP',       vol:.0005, market:'forex',     icon:'£',  dp:5, fallback:1.2741},
  'XAU/USD':  { coinId:'gold',     vol:5.5,   market:'commodity', icon:'Au', dp:2, fallback:2341  },
  'WTI/USD':  { vol:.38,           market:'commodity', icon:'🛢', dp:2,      fallback:82.40 },
}

function calcRSI(arr, period = 14) {
  if (arr.length < period + 1) return 50
  const changes = arr.slice(1).map((v, i) => v - arr[i])
  const slice   = changes.slice(-period)
  const ag = slice.map(c=>c>0?c:0).reduce((a,b)=>a+b,0)/period
  const al = slice.map(c=>c<0?-c:0).reduce((a,b)=>a+b,0)/period
  if (al === 0) return 99
  return Math.round(100 - 100 / (1 + ag / al))
}
function calcEMA(arr, period) {
  if (arr.length < period) return arr[arr.length-1]||0
  const k = 2/(period+1)
  let ema = arr.slice(0,period).reduce((a,b)=>a+b,0)/period
  for (let i=period; i<arr.length; i++) ema = arr[i]*k + ema*(1-k)
  return ema
}
function calcATR(prices, period=14) {
  if (prices.length < 2) return 0
  const trs = prices.slice(1).map((p,i)=>Math.abs(p-prices[i]))
  return trs.slice(-period).reduce((a,b)=>a+b,0)/Math.min(period,trs.length)
}

function buildSignal(symbol, history, price) {
  const meta = ASSETS[symbol]
  if (!price||price<=0) return null
  const rsi    = calcRSI(history)
  const ema9   = calcEMA(history, Math.min(9,   history.length))
  const ema21  = calcEMA(history, Math.min(21,  history.length))
  const ema50  = calcEMA(history, Math.min(50,  history.length))
  const ema200 = calcEMA(history, Math.min(200, history.length))
  const atr    = calcATR(history)||meta.vol*1.5
  const emaBull = ema50>ema200 && ema9>ema21
  const emaBear = ema50<ema200 && ema9<ema21
  let bull=0, bear=0
  if (emaBull)          bull+=30
  if (rsi>45&&rsi<65)   bull+=20
  if (rsi<40)           bull+=12
  if (price>ema50)      bull+=10
  if (emaBear)          bear+=30
  if (rsi>55&&rsi<75)   bear+=20
  if (rsi>70)           bear+=12
  if (price<ema50)      bear+=10
  if (bull<45&&bear<45) return null
  if (Math.abs(bull-bear)<10) return null
  const dir  = bull>bear?'BUY':'SELL'
  const conf = Math.min(94, (dir==='BUY'?bull:bear)+Math.floor(Math.random()*8))
  const sl   = dir==='BUY' ? parseFloat((price-atr*1.8).toFixed(meta.dp)) : parseFloat((price+atr*1.8).toFixed(meta.dp))
  const tp   = dir==='BUY' ? parseFloat((price+atr*3.0).toFixed(meta.dp)) : parseFloat((price-atr*3.0).toFixed(meta.dp))
  const riskPct   = ((Math.abs(price-sl)/price)*100).toFixed(2)
  const profitPct = ((Math.abs(tp-price)/price)*100).toFixed(2)
  const indicators = `EMA9=${ema9.toFixed(meta.dp)} | EMA21=${ema21.toFixed(meta.dp)} | EMA50=${ema50.toFixed(meta.dp)} | RSI=${rsi}`
  const exps = dir==='BUY' ? [
    `EMA9 (${ema9.toFixed(meta.dp)}) crossed above EMA21 with EMA50 > EMA200 — full bullish alignment. RSI at ${rsi} has room to run. ATR-based SL at ${sl} limits risk to ${riskPct}% targeting ${profitPct}%.`,
    `Multi-EMA confluence bullish. RSI ${rsi} — healthy momentum. Enter at market ${price}, SL ${sl}, TP ${tp}. Risk ${riskPct}%, target ${profitPct}%. R:R = 1:3.`,
  ] : [
    `EMA9 (${ema9.toFixed(meta.dp)}) below EMA21 with EMA50 < EMA200 — bearish alignment across all periods. RSI at ${rsi} confirms selling pressure. SL ${sl}, TP ${tp}. Risk ${riskPct}%, target ${profitPct}%.`,
    `Death cross structure. RSI ${rsi} distribution zone. Sell at ${price}, SL ${sl}, TP ${tp}. Risk ${riskPct}%, target ${profitPct}%. R:R = 1:3.`,
  ]
  return {
    id: `${symbol}-${Date.now()}-${Math.random().toString(36).slice(2,6)}`,
    symbol, market:meta.market, icon:meta.icon,
    direction:dir, price:parseFloat(price.toFixed(meta.dp)),
    sl, tp, confidence:conf, rsi,
    ema9:parseFloat(ema9.toFixed(meta.dp)),
    ema21:parseFloat(ema21.toFixed(meta.dp)),
    ema50:parseFloat(ema50.toFixed(meta.dp)),
    ema200:parseFloat(ema200.toFixed(meta.dp)),
    atr:parseFloat(atr.toFixed(meta.dp)),
    riskPct, profitPct, rr:'1:3', indicators,
    explanation:exps[Math.floor(Math.random()*exps.length)],
    timestamp:new Date(), status:'ACTIVE', dataSource:'live',
  }
}

async function fetchRealPrices() {
  const result = {}
  try {
    const cgRes = await fetch(
      'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana,gold&vs_currencies=usd&include_24hr_change=true',
      { signal: AbortSignal.timeout(10000) }
    )
    if (cgRes.ok) {
      const cg = await cgRes.json()
      if (cg.bitcoin?.usd)  result['BTC/USDT'] = { price:cg.bitcoin.usd,  pct24:cg.bitcoin.usd_24h_change||0 }
      if (cg.ethereum?.usd) result['ETH/USDT'] = { price:cg.ethereum.usd, pct24:cg.ethereum.usd_24h_change||0 }
      if (cg.solana?.usd)   result['SOL/USDT'] = { price:cg.solana.usd,   pct24:cg.solana.usd_24h_change||0 }
      if (cg.gold?.usd)     result['XAU/USD']  = { price:cg.gold.usd,     pct24:cg.gold.usd_24h_change||0 }
    }
  } catch {}
  try {
    const fxRes = await fetch('https://api.frankfurter.app/latest?from=USD&to=EUR,GBP', { signal:AbortSignal.timeout(8000) })
    if (fxRes.ok) {
      const fx = await fxRes.json()
      if (fx.rates?.EUR) result['EUR/USD'] = { price:parseFloat((1/fx.rates.EUR).toFixed(5)), pct24:0 }
      if (fx.rates?.GBP) result['GBP/USD'] = { price:parseFloat((1/fx.rates.GBP).toFixed(5)), pct24:0 }
    }
  } catch {}
  return result
}

export function useMarketData() {
  const [prices,   setPrices]   = useState(() =>
    Object.fromEntries(Object.entries(ASSETS).map(([s,m]) => [
      s, { price:m.fallback, change:0, pct:0, pct24:0, bid:m.fallback, ask:m.fallback*(1+.00005), prev:m.fallback, live:false }
    ]))
  )
  const [signals,  setSignals]  = useState([])
  const [dataLive, setDataLive] = useState(false)
  const history   = useRef(Object.fromEntries(Object.keys(ASSETS).map(s=>[s,[ASSETS[s].fallback]])))
  const lastPrice = useRef(Object.fromEntries(Object.entries(ASSETS).map(([s,m])=>[s,m.fallback])))
  const basePrices= useRef(Object.fromEntries(Object.entries(ASSETS).map(([s,m])=>[s,m.fallback])))

  const fetchAndUpdate = useCallback(async () => {
    const realData = await fetchRealPrices()
    if (Object.keys(realData).length > 0) setDataLive(true)

    setPrices(prev => {
      const next = {...prev}
      // Update real-data assets
      Object.entries(realData).forEach(([sym, data]) => {
        const price  = data.price
        const spread = price * 0.00006
        lastPrice.current[sym] = price
        history.current[sym].push(price)
        if (history.current[sym].length > 260) history.current[sym].shift()
        next[sym] = {
          price, prev:prev[sym].price,
          change: parseFloat((price-basePrices.current[sym]).toFixed(ASSETS[sym].dp)),
          pct:    parseFloat(((price-basePrices.current[sym])/basePrices.current[sym]*100).toFixed(3)),
          pct24:  data.pct24||0,
          bid:    parseFloat((price-spread).toFixed(ASSETS[sym].dp)),
          ask:    parseFloat((price+spread).toFixed(ASSETS[sym].dp)),
          live:   true,
        }
      })
      // Simulate WTI (no free API)
      Object.entries(ASSETS).forEach(([sym, meta]) => {
        if (realData[sym]) return
        const last  = prev[sym].price
        const drift = (Math.random()-0.498)*meta.vol*0.25
        const price = Math.max(parseFloat((last+drift).toFixed(meta.dp)), meta.fallback*0.5)
        const spread = price*0.00006
        lastPrice.current[sym] = price
        history.current[sym].push(price)
        if (history.current[sym].length > 260) history.current[sym].shift()
        next[sym] = {
          price, prev:last,
          change:parseFloat((price-meta.fallback).toFixed(meta.dp)),
          pct:parseFloat(((price-meta.fallback)/meta.fallback*100).toFixed(3)),
          pct24:prev[sym].pct24||0,
          bid:parseFloat((price-spread).toFixed(meta.dp)),
          ask:parseFloat((price+spread).toFixed(meta.dp)),
          live:false,
        }
      })
      return next
    })
  }, [])

  useEffect(() => {
    fetchAndUpdate()
    const priceInterval = setInterval(fetchAndUpdate, 30000)
    const sigEngine = setInterval(() => {
      const syms = Object.keys(ASSETS)
      const sym  = syms[Math.floor(Math.random()*syms.length)]
      const sig  = buildSignal(sym, history.current[sym], lastPrice.current[sym])
      if (sig) setSignals(prev=>[sig,...prev.slice(0,49)])
    }, 8000)
    const burst = setTimeout(() => {
      const initSigs = []
      Object.keys(ASSETS).forEach(sym => {
        const sig = buildSignal(sym, history.current[sym], lastPrice.current[sym])
        if (sig) initSigs.push(sig)
      })
      if (initSigs.length) setSignals(initSigs)
    }, 3500)
    return () => { clearInterval(priceInterval); clearInterval(sigEngine); clearTimeout(burst) }
  }, [fetchAndUpdate])

  const bestSignal = signals.reduce((best,s)=>(!best||s.confidence>best.confidence)?s:best, null)
  return { prices, signals, bestSignal, dataLive }
}
