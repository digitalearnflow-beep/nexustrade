import { useEffect, useRef } from 'react'

/* ================================================================
   AD COMPONENTS — All scripts from affiliate_ads_code.docx
   ✅ Social Bar  : pl29145513.profitablecpmratenetwork.com (index.html)
   ✅ Banner 728×90 key: 09802b8cb719e281979d9cf93ccae9df
   ✅ Mobile 320×50 key: a79e47e443b25417ae5849601d867ae5
   ✅ Native       : pl29145521.profitablecpmratenetwork.com
   All hidden for paid users automatically.
   ================================================================ */

export function DesktopBannerAd({ isPaid }) {
  const ref    = useRef(null)
  const loaded = useRef(false)
  useEffect(() => {
    if (isPaid || loaded.current || !ref.current) return
    loaded.current = true
    const opts = document.createElement('script')
    opts.innerHTML = `window.atOptions={'key':'09802b8cb719e281979d9cf93ccae9df','format':'iframe','height':90,'width':728,'params':{}};`
    const invoke   = document.createElement('script')
    invoke.src     = 'https://www.highperformanceformat.com/09802b8cb719e281979d9cf93ccae9df/invoke.js'
    invoke.async   = true
    ref.current.appendChild(opts)
    ref.current.appendChild(invoke)
  }, [isPaid])
  if (isPaid) return null
  return (
    <div className="ad-banner hide-mob" style={{ margin:'10px auto', maxWidth:728 }}>
      <div ref={ref} style={{ display:'flex', justifyContent:'center' }} />
    </div>
  )
}

export function MobileStickyAd({ isPaid }) {
  const ref    = useRef(null)
  const loaded = useRef(false)
  useEffect(() => {
    if (isPaid || loaded.current || !ref.current) return
    loaded.current = true
    const opts = document.createElement('script')
    opts.innerHTML = `window.atOptions={'key':'a79e47e443b25417ae5849601d867ae5','format':'iframe','height':50,'width':320,'params':{}};`
    const invoke   = document.createElement('script')
    invoke.src     = 'https://www.highperformanceformat.com/a79e47e443b25417ae5849601d867ae5/invoke.js'
    invoke.async   = true
    ref.current.appendChild(opts)
    ref.current.appendChild(invoke)
  }, [isPaid])
  if (isPaid) return null
  return (
    <div className="ad-sticky hide-desk">
      <div ref={ref} style={{ display:'flex', justifyContent:'center', alignItems:'center', width:'100%' }} />
    </div>
  )
}

export function NativeAd({ isPaid, style }) {
  const ref       = useRef(null)
  const loaded    = useRef(false)
  useEffect(() => {
    if (isPaid || loaded.current || !ref.current) return
    loaded.current = true
    ref.current.id = 'container-d0d80c3d97b13709eb67d685681c1f90'
    const s    = document.createElement('script')
    s.src      = 'https://pl29145521.profitablecpmratenetwork.com/d0d80c3d97b13709eb67d685681c1f90/invoke.js'
    s.async    = true
    s.setAttribute('data-cfasync','false')
    ref.current.parentNode.insertBefore(s, ref.current.nextSibling)
  }, [isPaid])
  if (isPaid) return null
  return (
    <div className="ad-native" style={style}>
      <div ref={ref} />
    </div>
  )
}
