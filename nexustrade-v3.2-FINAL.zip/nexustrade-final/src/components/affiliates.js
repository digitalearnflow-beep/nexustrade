/* ================================================================
   AFFILIATE LINKS — Verified from affiliate_ads_code.docx
   All 4 links confirmed correct.
   ================================================================ */
export const AFF = {
  CRYPTO: {
    url:      'http://heikoboos.com/the-cryptocurrency-secrets#aff=FussionFashion',
    label:    'Crypto Secrets Guide',
    cta:      'Copy This Trade on Binance →',
    ctaShort: 'Get Crypto Guide',
    desc:     'The complete crypto trading system used by 6-figure traders. Proven strategies, signals & execution blueprints.',
    badge:    '🔥 Most Popular',
    price:    '$47',
    stars:    5,
  },
  BUSINESS: {
    url:      'https://www.checkout-ds24.com/redir/610042/FussionFashion/',
    label:    'Trading Mastery Course',
    cta:      'Start Earning With This Signal →',
    ctaShort: 'Join Course',
    desc:     'Complete trading mastery: psychology, risk management, live trade setups & execution. 4,200+ students enrolled.',
    badge:    '⭐ Top Rated',
    price:    '$97',
    stars:    5,
  },
  EBOOK: {
    url:      'https://www.checkout-ds24.com/redir/633271/FussionFashion/',
    label:    'Trading eBook Bundle',
    cta:      'Download Trading eBooks →',
    ctaShort: 'Get eBooks',
    desc:     'In-depth eBooks: technical analysis, money management & advanced strategies. Instant download.',
    badge:    '📚 Free Bonus',
    price:    '$27',
    stars:    5,
  },
  MARKETING: {
    url:      'https://www.checkout-ds24.com/redir/625030/FussionFashion/',
    label:    'Marketing Accelerator',
    cta:      'Build Your Trading Business →',
    ctaShort: 'Scale Up',
    desc:     'Monetise your trading knowledge. Build a signal service, newsletter or course that generates passive income.',
    badge:    '💰 High Value',
    price:    '$147',
    stars:    4,
  },
}

export const AFF_LIST = Object.values(AFF)

export function affForMarket(market) {
  return market==='crypto' ? AFF.CRYPTO
    : market==='forex'     ? AFF.BUSINESS
    : market==='commodity' ? AFF.EBOOK
    : AFF.CRYPTO
}

/* Fire-and-forget click tracking to Netlify function + GA */
export function trackClick(name, page) {
  // Track in Supabase via Netlify function
  try {
    fetch('/.netlify/functions/track-click', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ affiliate: name, page, ts: Date.now() }),
    }).catch(() => {})
  } catch {}
  // Track in Google Analytics
  try {
    if (typeof window.gtag === 'function') {
      window.gtag('event', 'affiliate_click', {
        event_category: 'affiliate',
        event_label:    name,
        event_value:    page,
      })
    }
  } catch {}
}

/* Tracked redirect wrapper — use for all affiliate links
   onPreSell: optional callback to show pre-sell modal instead of direct jump */
export function AffLink({ href, name, page, children, style, className, onPreSell }) {
  const handleClick = (e) => {
    e.preventDefault()
    // Track immediately
    trackClick(name, page)
    // If pre-sell callback provided, show modal; else open after 350ms delay
    if (onPreSell) {
      onPreSell()
    } else {
      setTimeout(() => window.open(href, '_blank'), 350)
    }
  }
  return (
    <a href={href} target="_blank" rel="noopener noreferrer"
       style={style} className={className}
       onClick={handleClick}>
      {children}
    </a>
  )
}
